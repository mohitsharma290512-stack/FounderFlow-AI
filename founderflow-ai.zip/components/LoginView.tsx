
import React from 'react';
import { appLogo } from '../assets/logo';

interface LoginViewProps {
  onLogin: () => void;
}

const LoginView: React.FC<LoginViewProps> = ({ onLogin }) => {
  return (
    <div className="h-screen w-screen flex items-center justify-center bg-slate-50 dark:bg-[#0F0F1C]">
      <div className="text-center p-8 max-w-sm w-full bg-white dark:bg-[#1E1B3A] rounded-2xl shadow-2xl border border-slate-200 dark:border-[#2a274c]">
        <img src={appLogo} alt="AI Co-Founder Logo" className="h-24 w-24 mx-auto mb-6" />
        <h1 className="text-3xl font-bold text-[#2B2B2B] dark:text-[#E2E8F0] mb-2">Welcome to FounderFlow AI</h1>
        <p className="text-gray-600 dark:text-[#94A3B8] mb-8">Your strategic AI partner for building products.</p>
        <button
          onClick={onLogin}
          className="w-full p-4 rounded-xl bg-violet-500 text-white font-bold text-lg hover:bg-violet-600 transition-all"
        >
          Login as Guest
        </button>
      </div>
    </div>
  );
};

export default LoginView;
