

import React, { useState, useRef } from 'react';
import { generatePitchDeck } from '../services/geminiService';
import type { PitchDeckSlide } from '../types';
import LoadingSpinner from './LoadingSpinner';
import PptxGenJS from 'pptxgenjs';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';


const PitchDeckGenerator: React.FC = () => {
    const [idea, setIdea] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [slides, setSlides] = useState<PitchDeckSlide[] | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [isExporting, setIsExporting] = useState(false);
    
    const slideContainerRef = useRef<HTMLDivElement>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!idea.trim() || isLoading) return;

        setIsLoading(true);
        setError(null);
        setSlides(null);

        try {
            const result = await generatePitchDeck(idea);
            setSlides(result);
        } catch (err) {
            setError('An error occurred while generating the pitch deck.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleExportPPTX = () => {
        if (!slides) return;
        const pptx = new PptxGenJS();
        
        // Define colors from "The Visionary" palette
        const primaryColor = "6E44FF"; // Electric Purple
        const textColor = "E2E8F0"; // Light Gray
        const backgroundColor = "0F0F1C"; // Very Dark Blue/Purple
        const slideNumberColor = "94A3B8"; // Muted Gray

        // Define a master slide for consistent branding
        pptx.defineLayout({ name: 'MASTER_SLIDE', width: 10, height: 5.625 });
        pptx.layout = 'MASTER_SLIDE';
        
        pptx.defineSlideMaster({
            title: 'MASTER_SLIDE',
            background: { color: backgroundColor },
            objects: [
                { 'rect': { x: 0, y: 5.3, w: '100%', h: 0.32, fill: { color: primaryColor } } },
                { 'text': {
                    text: 'Confidential and Proprietary',
                    options: { x: 0, y: 5.3, w: '100%', align: 'center', color: textColor, fontSize: 10 }
                }}
            ],
        });
        
        // Title Slide
        const titleSlide = pptx.addSlide({ masterName: "MASTER_SLIDE" });
        titleSlide.addText(slides[0].title, {
            x: 0, y: 1.5, w: '100%', h: 1, 
            align: 'center', fontSize: 44, bold: true, color: 'FFFFFF'
        });
        titleSlide.addText(slides[0].content, {
            x: 0, y: 2.5, w: '100%', h: 1, 
            align: 'center', fontSize: 24, color: textColor
        });


        // Content Slides
        slides.slice(1).forEach((slide, index) => {
            const pptxSlide = pptx.addSlide({ masterName: "MASTER_SLIDE" });
            pptxSlide.addText(slide.title, { 
                x: 0.5, y: 0.5, w: '90%', h: 1, 
                fontSize: 28, bold: true, color: primaryColor
            });
            pptxSlide.addText(slide.content, { 
                x: 0.5, y: 1.5, w: '90%', h: 3.5, 
                fontSize: 16, color: textColor, bullet: { type: 'dot', color: primaryColor }
            });
             pptxSlide.addText(`Slide ${index + 2}`, {
                x: 0.5, y: 5.0, w: '90%', h: 0.25,
                fontSize: 10, color: slideNumberColor, align: 'right'
            });
        });

        pptx.writeFile({ fileName: 'Pitch-Deck.pptx' });
    };

    const handleExportPDF = async () => {
        if (!slideContainerRef.current) return;
        
        setIsExporting(true);
        const pdf = new jsPDF({
            orientation: 'landscape',
            unit: 'px',
            format: [800, 450] // 16:9 aspect ratio
        });

        const slideElements = Array.from(slideContainerRef.current.children) as HTMLElement[];

        for (let i = 0; i < slideElements.length; i++) {
            const slide = slideElements[i];
            const canvas = await html2canvas(slide, { scale: 2 });
            const imgData = canvas.toDataURL('image/png');
            
            if (i > 0) {
                pdf.addPage();
            }
            pdf.addImage(imgData, 'PNG', 0, 0, pdf.internal.pageSize.getWidth(), pdf.internal.pageSize.getHeight());
        }

        pdf.save('Pitch-Deck.pdf');
        setIsExporting(false);
    };

    const SlideComponent: React.FC<{ slide: PitchDeckSlide, index: number }> = ({ slide, index }) => (
        <div className="bg-white dark:bg-[#1E1B3A] aspect-video w-full p-6 rounded-2xl shadow-lg border border-slate-200 dark:border-[#2a274c] flex flex-col justify-between">
            <div>
                <h3 className="text-xl font-bold text-[#2B2B2B] dark:text-[#E2E8F0] mb-4">{slide.title}</h3>
                <ul className="space-y-2">
                    {slide.content.split('\n').filter(line => line.trim()).map((line, i) => (
                        <li key={i} className="text-gray-700 dark:text-[#E2E8F0]">{line}</li>
                    ))}
                </ul>
            </div>
            <p className="text-right text-sm text-gray-400 dark:text-[#94A3B8]">Slide {index + 1}</p>
        </div>
    );

    return (
        <div className="flex-grow flex flex-col p-4 md:p-6 items-center bg-slate-50 dark:bg-[#0F0F1C] overflow-y-auto">
            <div className="w-full max-w-3xl">
                <div className="text-center mb-8">
                    <h2 className="text-2xl font-bold text-[#2B2B2B] dark:text-[#E2E8F0] mb-2">Pitch Deck Auto-Generator</h2>
                    <p className="text-gray-600 dark:text-[#94A3B8]">Describe your startup, and I'll generate a 10-slide pitch deck for you.</p>
                </div>

                <form onSubmit={handleSubmit} className="mb-6">
                    <textarea
                        value={idea}
                        onChange={(e) => setIdea(e.target.value)}
                        placeholder="e.g., An AI-powered platform that connects home cooks with local customers for authentic meal delivery."
                        className="w-full bg-white dark:bg-[#1E1B3A] text-[#2B2B2B] dark:text-[#E2E8F0] text-base p-4 rounded-2xl shadow-lg border border-slate-200 dark:border-[#2a274c] focus:outline-none focus:ring-2 focus:ring-violet-500"
                        rows={3}
                        disabled={isLoading}
                    />
                    <button
                        type="submit"
                        disabled={isLoading || !idea.trim()}
                        className="mt-4 w-full p-4 rounded-xl bg-violet-500 text-white font-bold text-lg hover:bg-violet-600 disabled:bg-violet-300 disabled:cursor-not-allowed transition-all"
                    >
                        {isLoading ? 'Generating Pitch Deck...' : 'Generate Pitch Deck'}
                    </button>
                </form>
                 
                {error && <p className="text-red-500 bg-red-100 p-3 rounded-lg text-center">{error}</p>}
                
                {isLoading && (
                    <div className="text-center p-8">
                        <div className="flex justify-center"><LoadingSpinner /></div>
                        <p className="mt-2 text-gray-500 dark:text-[#94A3B8]">Tom is building your presentation...</p>
                    </div>
                )}

                {slides && (
                    <div className="animate-fade-in">
                        <div className="flex justify-center space-x-4 mb-6">
                            <button onClick={handleExportPPTX} className="px-6 py-2 bg-sky-500 text-white font-bold rounded-lg shadow-md hover:bg-sky-600 transition-colors">Export to PPTX</button>
                            <button onClick={handleExportPDF} disabled={isExporting} className="px-6 py-2 bg-emerald-500 text-white font-bold rounded-lg shadow-md hover:bg-emerald-600 transition-colors disabled:bg-gray-400">
                                {isExporting ? 'Exporting...' : 'Export to PDF'}
                            </button>
                        </div>
                        <div ref={slideContainerRef} className="space-y-6">
                            {slides.map((slide, index) => (
                                <SlideComponent key={index} slide={slide} index={index} />
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default PitchDeckGenerator;
