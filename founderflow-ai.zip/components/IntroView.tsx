import React, { useState, useRef, useEffect } from 'react';
import { getSimulationResponse } from '../services/geminiService';
import type { Message } from '../types';
import LoadingSpinner from './LoadingSpinner';

const FounderSimulation: React.FC = () => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isStarted, setIsStarted] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);
    
    const handleStart = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!input.trim() || isLoading) return;
        setIsStarted(true);
        await handleSend(input, true);
    };

    const handleSend = async (text: string, isFirstMessage: boolean = false) => {
        const prompt = text.trim();
        if (!prompt || isLoading) return;

        setIsLoading(true);
        
        const userMessage: Message = { id: Date.now().toString(), role: 'user', content: prompt, timestamp: Date.now() };
        
        const currentMessages = isFirstMessage 
          ? [{ role: 'assistant', content: 'Tell me about your business to start the simulation...', id: 'start', timestamp: Date.now()-1}, userMessage]
          : [...messages, userMessage];

        setMessages(currentMessages);
        setInput('');

        const history = currentMessages
            .map(m => ({
                role: m.role === 'assistant' ? 'model' : 'user',
                parts: [{ text: m.content }],
            }));
        
        try {
            const responseText = await getSimulationResponse(prompt, history);
            const assistantMessage: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: responseText, timestamp: Date.now() + 1 };
            setMessages(prev => [...prev, assistantMessage]);
        } catch(error) {
            console.error(error);
            const errorMessage: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: "Sorry, the simulation ran into an issue. Please try again.", timestamp: Date.now() + 1 };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };
    
    const renderContent = (content: string) => {
        const parts = content.split('**');
        return parts.map((part, index) => {
            if (index % 2 === 1) { // Text between **
                return <strong key={index} className="text-violet-500">{part}</strong>;
            }
            return part.split('\n').map((line, lineIndex) => <p key={`${index}-${lineIndex}`} className="mb-2">{line}</p>);
        });
    };

    if (!isStarted) {
        return (
            <div className="flex-grow flex flex-col p-4 md:p-6 items-center justify-center bg-slate-50 dark:bg-[#0F0F1C]">
                <div className="w-full max-w-2xl text-center">
                    <h2 className="text-2xl font-bold text-[#2B2B2B] dark:text-[#E2E8F0] mb-4">Founder Simulation</h2>
                    <p className="text-gray-600 dark:text-[#94A3B8] mb-6">Test your decision-making skills in realistic startup scenarios. Describe your business to begin.</p>
                    <form onSubmit={handleStart} className="flex flex-col gap-4">
                        <textarea
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder="e.g., A SaaS for small businesses to manage their social media."
                            className="w-full bg-white dark:bg-[#1E1B3A] text-[#2B2B2B] dark:text-[#E2E8F0] text-base p-4 rounded-2xl shadow-lg border border-slate-200 dark:border-[#2a274c] focus:outline-none focus:ring-2 focus:ring-violet-500"
                            rows={3}
                            disabled={isLoading}
                        />
                        <button
                            type="submit"
                            disabled={isLoading || !input.trim()}
                            className="w-full p-4 rounded-xl bg-violet-500 text-white font-bold text-lg hover:bg-violet-600 disabled:bg-violet-300 disabled:cursor-not-allowed transition-all"
                        >
                            {isLoading ? <LoadingSpinner /> : 'Start Simulation'}
                        </button>
                    </form>
                </div>
            </div>
        );
    }

    return (
        <div className="flex-grow flex flex-col h-full overflow-hidden">
            <main className="flex-grow overflow-y-auto p-4 md:p-6">
                <div className="max-w-3xl mx-auto">
                    {messages.map((msg) => (
                         <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} mb-6 animate-fade-in`}>
                            <div className={`p-4 md:p-5 max-w-lg shadow-md rounded-xl ${msg.role === 'user' ? 'bg-white dark:bg-violet-600 dark:text-white rounded-br-none' : 'bg-white dark:bg-[#1E1B3A] text-[#2B2B2B] dark:text-[#E2E8F0] rounded-bl-none'}`}>
                                <div className="text-base leading-relaxed">{renderContent(msg.content)}</div>
                            </div>
                        </div>
                    ))}
                    {isLoading && (
                         <div className="flex justify-start mb-6">
                            <div className="p-4 md:p-5 max-w-lg shadow-md rounded-xl bg-white dark:bg-[#1E1B3A] text-[#2B2B2B] dark:text-[#E2E8F0] rounded-bl-none">
                                <LoadingSpinner/>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>
            </main>
            <div className="sticky bottom-0 left-0 right-0 p-2 sm:p-4 bg-slate-50/80 dark:bg-[#0F0F1C]/80 backdrop-blur-sm">
                 <div className="max-w-3xl mx-auto flex items-center gap-2 sm:gap-4 p-2 bg-white dark:bg-[#1E1B3A] rounded-2xl shadow-lg border border-slate-200 dark:border-[#2a274c]">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        placeholder="What do you do?"
                        className="flex-grow bg-transparent text-[#2B2B2B] dark:text-[#E2E8F0] text-base p-2 focus:outline-none"
                        disabled={isLoading}
                        onKeyDown={(e) => e.key === 'Enter' && !isLoading && handleSend(input)}
                    />
                    <button
                        onClick={() => handleSend(input)}
                        disabled={isLoading || !input.trim()}
                        className="p-3 rounded-xl bg-violet-500 hover:bg-violet-600 disabled:bg-violet-300 disabled:cursor-not-allowed transition-all"
                    >
                        {isLoading ? <div className="w-6 h-6"><LoadingSpinner /></div> : <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>}
                    </button>
                 </div>
            </div>
        </div>
    );
};

export default FounderSimulation;
