
import React, { useState } from 'react';
import type { Message } from '../types';
import LoadingSpinner from './LoadingSpinner';

interface MessageProps {
  message: Message;
  onPlayAudio: (messageId: string) => void;
  onDeleteMessage: (messageId: string) => void;
  onUpdateMessage: (messageId: string, newContent: string) => void;
  audioState: 'idle' | 'loading' | 'playing';
}

const renderContent = (content: string) => {
  if (content === '...') {
    return (
      <div className="flex items-center space-x-2">
        <LoadingSpinner />
        <span className="text-gray-500 dark:text-[#94A3B8]">Tom is thinking...</span>
      </div>
    )
  }

  const lines = content.split('\n').filter(line => line.trim() !== '');
  
  return lines.map((line, index) => {
    if (line.startsWith('**') && line.endsWith('**')) {
      return (
        <h3 key={index} className="text-lg font-bold text-violet-600 dark:text-violet-400 mt-4 mb-2">
          {line.substring(2, line.length - 2)}
        </h3>
      );
    }
    if (line.trim().startsWith('- ')) {
      return (
        <li key={index} className="ml-5 list-disc text-gray-700 dark:text-[#E2E8F0]">
          {line.trim().substring(2)}
        </li>
      );
    }
    return (
      <p key={index} className="text-[#2B2B2B] dark:text-[#E2E8F0] text-base leading-relaxed">
        {line}
      </p>
    );
  });
};

const AudioButton: React.FC<{ state: 'idle' | 'loading' | 'playing', onClick: () => void }> = ({ state, onClick }) => {
    if (state === 'loading') {
        return <div className="w-8 h-8 flex items-center justify-center"><LoadingSpinner /></div>;
    }
    const Icon = state === 'playing'
        ? <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
        : <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>;

    return (
        <button onClick={onClick} className="p-1 rounded-full text-violet-500 dark:text-violet-400 hover:bg-slate-100 dark:hover:bg-[#2a274c] transition-colors">
            {Icon}
        </button>
    );
};

const MessageComponent: React.FC<MessageProps> = ({ message, onPlayAudio, onDeleteMessage, onUpdateMessage, audioState }) => {
  const isUser = message.role === 'user';
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState(message.content);

  const wrapperClasses = isUser ? 'flex justify-end' : 'flex justify-start';
  const bubbleClasses = isUser
    ? 'bg-white dark:bg-violet-600 dark:text-white text-[#2B2B2B] rounded-xl rounded-br-none'
    : 'bg-white dark:bg-[#1E1B3A] text-[#2B2B2B] dark:text-[#E2E8F0] rounded-xl rounded-bl-none';
  const bubbleStyles = `p-4 md:p-5 max-w-lg shadow-md transition-all duration-300 ease-in-out group relative`;
  
  const handleSave = () => {
    if (editedContent.trim()) {
      onUpdateMessage(message.id, editedContent);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditedContent(message.content);
    setIsEditing(false);
  };
  
  const formattedTime = new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

  return (
    <div className={`${wrapperClasses} mb-6 animate-fade-in`}>
      <div className={`${bubbleClasses} ${bubbleStyles}`}>
        {isUser ? (
          isEditing ? (
            <div>
              <textarea
                value={editedContent}
                onChange={(e) => setEditedContent(e.target.value)}
                className="w-full p-2 rounded-md bg-slate-100 dark:bg-[#0F0F1C] border-slate-300 dark:border-[#2a274c] focus:outline-none focus:ring-2 focus:ring-violet-500"
                rows={3}
              />
              <div className="flex justify-end space-x-2 mt-2">
                <button onClick={handleCancel} className="px-3 py-1 text-xs font-semibold rounded-md hover:bg-gray-200 dark:hover:bg-[#2a274c]">Cancel</button>
                <button onClick={handleSave} className="px-3 py-1 text-xs font-semibold rounded-md bg-violet-500 text-white">Save</button>
              </div>
            </div>
          ) : (
            <>
              <p className="text-base">{message.content}</p>
              <div className="absolute top-1 right-1 flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => setIsEditing(true)} className="p-1 rounded-full hover:bg-slate-200 dark:hover:bg-violet-700">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.5L16.732 3.732z" /></svg>
                </button>
                <button onClick={() => onDeleteMessage(message.id)} className="p-1 rounded-full hover:bg-slate-200 dark:hover:bg-violet-700">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                </button>
              </div>
            </>
          )
        ) : (
          <div className="flex items-start space-x-3">
            <div className="flex-grow">{renderContent(message.content)}</div>
            {message.audioData && message.content !== '...' && <AudioButton state={audioState} onClick={() => onPlayAudio(message.id)} />}
          </div>
        )}
         <div className="text-right text-xs mt-2 opacity-70">
            {formattedTime}
        </div>
      </div>
    </div>
  );
};

export default MessageComponent;
