export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  audioData?: string;
}

export interface BusinessModelCanvas {
    keyPartners: string[];
    keyActivities: string[];
    valuePropositions: string[];
    customerRelationships: string[];
    customerSegments: string[];
    keyResources: string[];
    channels: string[];
    costStructure: string[];
    revenueStreams: string[];
}

export interface FinancialProjection {
    year: number;
    revenue: string;
    profit: string;
    assumptions: string;
}

export interface Competitor {
    name: string;
    strengths: string;
    weaknesses: string;
}

export interface BusinessCanvasData {
    canvas: BusinessModelCanvas;
    projections: FinancialProjection[];
    competitors: Competitor[];
}


export interface PitchDeckSlide {
  title: string;
  content: string;
}
