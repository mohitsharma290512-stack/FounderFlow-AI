
import React, { useState, useRef, useEffect, useCallback } from 'react';
import type { Message } from './types';
import MessageComponent from './components/Message';
import InputBar from './components/InputBar';
import ImageGenerator from './components/ImageGenerator';
import MarketingStrategist from './components/MarketingStrategist';
import BusinessCanvas from './components/Dashboard'; // Renamed Dashboard to BusinessCanvas conceptually
import PitchDeckGenerator from './components/PitchDeckGenerator';
import FounderSimulation from './components/IntroView'; // Re-purposing IntroView for FounderSimulation
import LoginView from './components/LoginView';
import { coFounderImage } from './assets/images';
import { appLogo } from './assets/logo';
import { decode, decodeAudioData, encode } from './utils/audio';
import { GoogleGenAI, LiveSession, Modality, Blob, LiveServerMessage } from '@google/genai';
import { getCoFounderResponseStream, generateSpeech } from './services/geminiService';

type View = 'chat' | 'imageGenerator' | 'marketing' | 'businessCanvas' | 'pitch' | 'simulation';
type Theme = 'light' | 'dark';
type AudioState = 'idle' | 'loading' | 'playing';
type Persona = 'default' | 'visionary' | 'cfo';

const LIVE_SYSTEM_INSTRUCTION = `Your name is Tom, your virtual co-founder. You are smart, resourceful, and practical. Speak clearly and concisely. Act as a partner helping to build a startup.`;

const getInitialMessages = (): Message[] => {
  try {
    const savedHistory = localStorage.getItem('chatHistory');
    if (savedHistory) {
      const parsedHistory = JSON.parse(savedHistory);
      if (Array.isArray(parsedHistory) && parsedHistory.length > 0) {
        return parsedHistory;
      }
    }
  } catch (e) {
    console.error("Failed to parse chat history from localStorage", e);
  }
  return [
    {
      id: 'intro-1',
      role: 'assistant',
      content: "Welcome! I'm Tom, your AI Co-Founder. Type a message below or click the mic to start our session.",
      timestamp: Date.now(),
    },
  ];
};

const getInitialTheme = (): Theme => {
  const savedTheme = localStorage.getItem('theme') as Theme | null;
  if (savedTheme) return savedTheme;
  if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) return 'dark';
  return 'light';
};

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [messages, setMessages] = useState<Message[]>(getInitialMessages());
  const [isSessionActive, setIsSessionActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [language, setLanguage] = useState('en');
  const [view, setView] = useState<View>('chat');
  const [theme, setTheme] = useState<Theme>(getInitialTheme());
  const [audioStates, setAudioStates] = useState<{ [id: string]: AudioState }>({});
  const [persona, setPersona] = useState<Persona>('default');

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const avatarRef = useRef<HTMLImageElement>(null);
  const sessionPromiseRef = useRef<Promise<LiveSession> | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const playingAudioSourceRef = useRef<{ source: AudioBufferSourceNode, messageId: string } | null>(null);
  const nextStartTimeRef = useRef(0);
  const audioQueueRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const analyserNodeRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number>();
  
  useEffect(() => {
    const loggedInStatus = localStorage.getItem('isLoggedIn');
    if (loggedInStatus === 'true') {
      setIsLoggedIn(true);
    }
  }, []);

  useEffect(() => {
    if (isLoggedIn) {
        localStorage.setItem('chatHistory', JSON.stringify(messages));
    }
  }, [messages, isLoggedIn]);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);
  
  const handleLogin = () => {
    localStorage.setItem('isLoggedIn', 'true');
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('chatHistory');
    setIsLoggedIn(false);
    setMessages(getInitialMessages()); 
  };

  const toggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);
  
  const animateAvatar = useCallback(() => {
    if (!analyserNodeRef.current || !avatarRef.current) return;
    
    const analyser = analyserNodeRef.current;
    const dataArray = new Uint8Array(analyser.frequencyBinCount);
    analyser.getByteFrequencyData(dataArray);

    const average = dataArray.reduce((acc, val) => acc + val, 0) / dataArray.length;
    const scale = 1 + (average / 256) * 0.1; // Subtle scaling effect
    
    if (avatarRef.current) {
      avatarRef.current.style.transform = `scale(${scale})`;
    }

    animationFrameRef.current = requestAnimationFrame(animateAvatar);
  }, []);

  const cleanupAudioSources = useCallback(() => {
    audioQueueRef.current.forEach(source => {
      source.stop();
      source.disconnect();
    });
    audioQueueRef.current.clear();
    nextStartTimeRef.current = 0;
  }, []);

  const stopCurrentPlayback = useCallback(() => {
    if (playingAudioSourceRef.current) {
      playingAudioSourceRef.current.source.stop();
      playingAudioSourceRef.current.source.disconnect();
      setAudioStates(prev => ({ ...prev, [playingAudioSourceRef.current!.messageId]: 'idle' }));
      playingAudioSourceRef.current = null;
    }
  }, []);
  
  const stopSession = useCallback(async () => {
    setIsSessionActive(false);
    cleanupAudioSources();

    if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = undefined;
        if(avatarRef.current) avatarRef.current.style.transform = 'scale(1)';
    }

    if (sessionPromiseRef.current) {
        try {
            const session = await sessionPromiseRef.current;
            session.close();
        } catch (e) {
            console.error("Error closing session:", e);
        }
        sessionPromiseRef.current = null;
    }

    if (scriptProcessorRef.current) {
        scriptProcessorRef.current.disconnect();
        scriptProcessorRef.current = null;
    }
    if (mediaStreamSourceRef.current) {
        mediaStreamSourceRef.current.disconnect();
        mediaStreamSourceRef.current = null;
    }
    if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach(track => track.stop());
        mediaStreamRef.current = null;
    }
    if (analyserNodeRef.current) {
        analyserNodeRef.current.disconnect();
        analyserNodeRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
        await audioContextRef.current.close();
        audioContextRef.current = null;
    }
    if (outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
        await outputAudioContextRef.current.close();
        outputAudioContextRef.current = null;
    }
}, [cleanupAudioSources]);


  const startSession = useCallback(async () => {
    if (isSessionActive || isConnecting) return;

    setIsConnecting(true);
    setMessages(prev => [...prev, { id: 'start-session', role: 'assistant', content: 'Listening...', timestamp: Date.now()}]);
    
    let currentInputTranscription = '';
    let currentOutputTranscription = '';

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        sessionPromiseRef.current = ai.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            config: {
                systemInstruction: LIVE_SYSTEM_INSTRUCTION,
                responseModalities: [Modality.AUDIO],
                inputAudioTranscription: {},
                outputAudioTranscription: {},
                speechConfig: {
                    voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
                },
            },
            callbacks: {
                onopen: async () => {
                    audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
                    outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
                    
                    analyserNodeRef.current = outputAudioContextRef.current.createAnalyser();
                    analyserNodeRef.current.fftSize = 256;

                    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                    mediaStreamRef.current = stream;
                    
                    const source = audioContextRef.current.createMediaStreamSource(stream);
                    mediaStreamSourceRef.current = source;

                    const scriptProcessor = audioContextRef.current.createScriptProcessor(4096, 1, 1);
                    scriptProcessorRef.current = scriptProcessor;

                    scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                        const pcmBlob: Blob = {
                            data: encode(new Uint8Array(new Int16Array(inputData.map(x => x * 32768)).buffer)),
                            mimeType: 'audio/pcm;rate=16000',
                        };
                        sessionPromiseRef.current?.then((session) => {
                            session.sendRealtimeInput({ media: pcmBlob });
                        });
                    };
                    source.connect(scriptProcessor);
                    scriptProcessor.connect(audioContextRef.current.destination);
                    
                    setIsConnecting(false);
                    setIsSessionActive(true);
                    animationFrameRef.current = requestAnimationFrame(animateAvatar);
                },
                onmessage: async (message: LiveServerMessage) => {
                    // Handle Transcription
                    if (message.serverContent?.inputTranscription) {
                        currentInputTranscription += message.serverContent.inputTranscription.text;
                    }
                    if (message.serverContent?.outputTranscription) {
                        currentOutputTranscription += message.serverContent.outputTranscription.text;
                    }

                    if (message.serverContent?.turnComplete) {
                        const userMessage: Message = { id: Date.now().toString(), role: 'user', content: currentInputTranscription || " ", timestamp: Date.now() };
                        const assistantMessage: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: currentOutputTranscription, timestamp: Date.now() + 1 };
                        setMessages(prev => [...prev.filter(m => m.id !== 'start-session'), userMessage, assistantMessage]);
                        currentInputTranscription = '';
                        currentOutputTranscription = '';
                    }

                    // Handle Audio
                    const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                    if (base64Audio && outputAudioContextRef.current && analyserNodeRef.current) {
                        const ctx = outputAudioContextRef.current;
                        nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
                        const buffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
                        
                        const source = ctx.createBufferSource();
                        source.buffer = buffer;
                        source.connect(analyserNodeRef.current);
                        analyserNodeRef.current.connect(ctx.destination);
                        
                        source.onended = () => {
                          audioQueueRef.current.delete(source);
                          if(audioQueueRef.current.size === 0 && avatarRef.current) {
                             avatarRef.current.style.transform = 'scale(1)';
                          }
                        };
                        source.start(nextStartTimeRef.current);
                        nextStartTimeRef.current += buffer.duration;
                        audioQueueRef.current.add(source);
                    }
                },
                onerror: (e: ErrorEvent) => {
                    console.error("Session error:", e);
                    setMessages(prev => [...prev.filter(m => m.id !== 'start-session'), { id: 'error', role: 'assistant', content: 'Session error. Please try again.', timestamp: Date.now() }]);
                    stopSession();
                },
                onclose: () => {
                    stopSession();
                },
            },
        });
    } catch (error) {
        console.error("Failed to start session:", error);
        setIsConnecting(false);
        setMessages(prev => [...prev.filter(m => m.id !== 'start-session'), { id: 'error-start', role: 'assistant', content: 'Could not start the session. Please check microphone permissions.', timestamp: Date.now() }]);
    }
  }, [isSessionActive, isConnecting, stopSession, animateAvatar]);

  const toggleSession = () => {
    if (isSessionActive) {
      stopSession();
    } else {
      startSession();
    }
  };

  const handleSendMessage = async (text: string) => {
    setIsSending(true);
    const userMessage: Message = { id: Date.now().toString(), role: 'user', content: text, timestamp: Date.now() };
    const assistantPlaceholder: Message = { id: (Date.now() + 1).toString(), role: 'assistant', content: '...', timestamp: Date.now() + 1 };
    
    const currentMessages = [...messages, userMessage];
    setMessages([...currentMessages, assistantPlaceholder]);
    
    const history = currentMessages
      .filter(m => m.id !== 'intro-1')
      .map(m => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      }));
      
    try {
        const stream = getCoFounderResponseStream(text, language, history, persona);
        let fullResponse = '';

        for await (const chunk of stream) {
            fullResponse += chunk;
            setMessages(prev => prev.map(m => 
                m.id === assistantPlaceholder.id ? { ...m, content: fullResponse } : m
            ));
        }

        const audioData = await generateSpeech(fullResponse);
        setMessages(prev => prev.map(m => 
            m.id === assistantPlaceholder.id ? { ...m, audioData: audioData || undefined, timestamp: Date.now() } : m
        ));
    } catch(error) {
        console.error(error);
        const errorMessageContent = error instanceof Error ? error.message : "Sorry, I ran into an issue. Please try again.";
        const errorMessage: Message = { ...assistantPlaceholder, content: errorMessageContent, timestamp: Date.now() };
        setMessages(prev => prev.map(m => m.id === assistantPlaceholder.id ? errorMessage : m));
    } finally {
        setIsSending(false);
    }
  };
  
  const handlePlayAudio = async (messageId: string) => {
      stopCurrentPlayback();
      if (playingAudioSourceRef.current?.messageId === messageId) return;

      const message = messages.find(m => m.id === messageId);
      if (!message) return;

      let audioData = message.audioData;
      if (!audioData) {
          setAudioStates(prev => ({ ...prev, [messageId]: 'loading' }));
          audioData = await generateSpeech(message.content);
          if (audioData) {
              setMessages(prev => prev.map(m => m.id === messageId ? { ...m, audioData } : m));
          } else {
              setAudioStates(prev => ({ ...prev, [messageId]: 'idle' }));
              return;
          }
      }

      if (audioData) {
          outputAudioContextRef.current = outputAudioContextRef.current || new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
          const ctx = outputAudioContextRef.current;
          const buffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
          const source = ctx.createBufferSource();
          source.buffer = buffer;
          source.connect(ctx.destination);
          source.onended = () => {
              setAudioStates(prev => ({ ...prev, [messageId]: 'idle' }));
              playingAudioSourceRef.current = null;
          };
          source.start();
          playingAudioSourceRef.current = { source, messageId };
          setAudioStates(prev => ({ ...prev, [messageId]: 'playing' }));
      }
  };

  const handleDeleteMessage = (messageId: string) => {
      setMessages(prev => prev.filter(m => m.id !== messageId));
  };
  
  const handleUpdateMessage = (messageId: string, newContent: string) => {
      setMessages(prev => prev.map(m => m.id === messageId ? { ...m, content: newContent } : m));
  };

  const NavButton: React.FC<{ currentView: View, viewName: View, setView: (view: View) => void, children: React.ReactNode }> = ({ currentView, viewName, setView, children }) => (
    <button onClick={() => setView(viewName)} className={`px-3 py-2 text-xs sm:text-sm font-bold rounded-lg transition-colors ${currentView === viewName ? 'bg-violet-500 text-white' : 'bg-white text-[#2B2B2B] hover:bg-slate-100 dark:bg-[#1E1B3A] dark:text-[#E2E8F0] dark:hover:bg-[#2a274c]'}`}>
        {children}
    </button>
  );

  const ThemeToggleButton: React.FC = () => (
    <button
        onClick={toggleTheme}
        className="p-2 rounded-full text-violet-500 hover:bg-slate-200 dark:text-violet-400 dark:hover:bg-[#1E1B3A] transition-colors"
        aria-label="Toggle theme"
    >
        {theme === 'light' ? (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
        ) : (
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
        )}
    </button>
  );

  if (!isLoggedIn) {
    return <LoginView onLogin={handleLogin} />;
  }

  return (
    <div className="h-screen w-screen flex flex-col md:flex-row">
      <style>{`
        @keyframes fade-in { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .animate-fade-in { animation: fade-in 0.5s ease-out forwards; }
        @keyframes breathe {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.02); }
        }
        .animate-breathe {
          animation: breathe 5s ease-in-out infinite;
        }
      `}</style>
      
      <div className="relative md:w-1/2 lg:w-2/5 xl:w-1/3 bg-slate-100 dark:bg-[#161528] flex items-center justify-center p-4 md:h-screen md:sticky top-0 overflow-hidden">
        <img
          ref={avatarRef}
          src={coFounderImage}
          alt="AI Co-Founder Tom"
          className="rounded-full w-48 h-48 md:w-64 md:h-64 object-cover shadow-2xl border-4 border-white transition-transform duration-200 ease-in-out animate-breathe"
        />
      </div>

      <div className="flex-1 flex flex-col h-full overflow-hidden">
        <header className="p-3 px-4 border-b border-slate-200 dark:border-[#2a274c] bg-slate-50/80 dark:bg-[#0F0F1C]/80 backdrop-blur-sm z-10 flex justify-between items-center flex-wrap gap-2">
            <div className="flex items-center gap-2 sm:gap-4">
                <div className="flex items-center gap-3 flex-shrink-0">
                    <img src={appLogo} alt="AI Co-Founder Logo" className="h-10 w-10" />
                    <h1 className="text-lg font-bold text-[#2B2B2B] dark:text-[#E2E8F0] hidden sm:block">AI Co-Founder</h1>
                </div>
            </div>
            <div className="flex items-center space-x-1 sm:space-x-2 flex-wrap">
                <NavButton currentView={view} viewName="chat" setView={setView}>Co-Founder</NavButton>
                <NavButton currentView={view} viewName="businessCanvas" setView={setView}>Business Canvas</NavButton>
                <NavButton currentView={view} viewName="pitch" setView={setView}>Pitch Deck</NavButton>
                <NavButton currentView={view} viewName="marketing" setView={setView}>Marketing</NavButton>
                <NavButton currentView={view} viewName="simulation" setView={setView}>Simulation</NavButton>
                <NavButton currentView={view} viewName="imageGenerator" setView={setView}>Imagen</NavButton>
            </div>
            <div className="flex items-center gap-2">
                <select
                    value={persona}
                    onChange={(e) => setPersona(e.target.value as Persona)}
                    className="bg-white dark:bg-[#1E1B3A] border border-slate-300 dark:border-[#2a274c] rounded-md px-2 py-1.5 text-xs sm:text-sm text-[#2B2B2B] dark:text-[#E2E8F0] focus:outline-none focus:ring-2 focus:ring-violet-500"
                    aria-label="Select AI Persona"
                >
                    <option value="default">Practical</option>
                    <option value="visionary">Visionary</option>
                    <option value="cfo">CFO</option>
                </select>
                <select
                    value={language}
                    onChange={(e) => setLanguage(e.target.value)}
                    className="bg-white dark:bg-[#1E1B3A] border border-slate-300 dark:border-[#2a274c] rounded-md px-2 py-1.5 text-xs sm:text-sm text-[#2B2B2B] dark:text-[#E2E8F0] focus:outline-none focus:ring-2 focus:ring-violet-500"
                    aria-label="Select language"
                >
                    <option value="en">English</option>
                    <option value="es">Español</option>
                </select>
                <ThemeToggleButton />
                <button
                    onClick={handleLogout}
                    className="p-2 rounded-full text-violet-500 hover:bg-slate-200 dark:text-violet-400 dark:hover:bg-[#1E1B3A] transition-colors"
                    aria-label="Logout"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" /></svg>
                </button>
            </div>
        </header>
        
        {view === 'chat' && (
          <>
            <main className="flex-grow overflow-y-auto p-4 md:p-6">
              <div className="max-w-3xl mx-auto">
                {messages.map((msg) => (
                  <MessageComponent 
                    key={msg.id} 
                    message={msg} 
                    onPlayAudio={handlePlayAudio} 
                    onDeleteMessage={handleDeleteMessage}
                    onUpdateMessage={handleUpdateMessage}
                    audioState={audioStates[msg.id] || 'idle'} 
                  />
                ))}
                <div ref={messagesEndRef} />
              </div>
            </main>
            <InputBar 
              onSendMessage={handleSendMessage}
              isSending={isSending}
              isSessionActive={isSessionActive} 
              isConnecting={isConnecting} 
              toggleSession={toggleSession} 
            />
          </>
        )}
        {view === 'imageGenerator' && <ImageGenerator />}
        {view === 'marketing' && <MarketingStrategist />}
        {view === 'businessCanvas' && <BusinessCanvas />}
        {view === 'pitch' && <PitchDeckGenerator />}
        {view === 'simulation' && <FounderSimulation />}
      </div>
    </div>
  );
};

export default App;
