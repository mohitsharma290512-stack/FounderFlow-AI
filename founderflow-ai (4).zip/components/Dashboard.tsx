

import React, { useState } from 'react';
import { generateBusinessCanvas } from '../services/geminiService';
import type { BusinessCanvasData } from '../types';
import LoadingSpinner from './LoadingSpinner';

const BusinessCanvas: React.FC = () => {
    const [idea, setIdea] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [canvasData, setCanvasData] = useState<BusinessCanvasData | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!idea.trim() || isLoading) return;

        setIsLoading(true);
        setError(null);
        setCanvasData(null);

        try {
            const result = await generateBusinessCanvas(idea);
            setCanvasData(result);
        } catch (err) {
            setError('An error occurred while generating the business canvas.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };
    
    const CanvasCard: React.FC<{ title: string; items: string[] | undefined; className?: string }> = ({ title, items, className = '' }) => (
        <div className={`bg-white dark:bg-[#1E1B3A] p-4 rounded-xl shadow-lg border border-slate-200 dark:border-[#2a274c] ${className}`}>
            <h3 className="text-sm font-bold text-violet-600 dark:text-violet-400 mb-2 border-b border-slate-200 dark:border-[#2a274c] pb-2">{title}</h3>
            <ul className="space-y-1.5">
                {items?.map((item, index) => (
                    <li key={index} className="text-xs text-gray-700 dark:text-[#E2E8F0]">{item}</li>
                ))}
            </ul>
        </div>
    );

    return (
        <div className="flex-grow flex flex-col p-4 md:p-6 items-center bg-slate-50 dark:bg-[#0F0F1C] overflow-y-auto">
            <div className="w-full max-w-6xl">
                <div className="text-center mb-8">
                    <h2 className="text-2xl font-bold text-[#2B2B2B] dark:text-[#E2E8F0] mb-2">Dynamic Business Canvas</h2>
                    <p className="text-gray-600 dark:text-[#94A3B8]">Enter your startup idea to generate a complete business model, financial projections, and competitive analysis.</p>
                </div>

                <form onSubmit={handleSubmit} className="mb-6 max-w-3xl mx-auto">
                    <textarea
                        value={idea}
                        onChange={(e) => setIdea(e.target.value)}
                        placeholder="e.g., A subscription box service for rare indoor plants."
                        className="w-full bg-white dark:bg-[#1E1B3A] text-[#2B2B2B] dark:text-[#E2E8F0] text-base p-4 rounded-2xl shadow-lg border border-slate-200 dark:border-[#2a274c] focus:outline-none focus:ring-2 focus:ring-violet-500"
                        rows={3}
                        disabled={isLoading}
                    />
                    <button
                        type="submit"
                        disabled={isLoading || !idea.trim()}
                        className="mt-4 w-full p-4 rounded-xl bg-violet-500 text-white font-bold text-lg hover:bg-violet-600 disabled:bg-violet-300 disabled:cursor-not-allowed transition-all"
                    >
                        {isLoading ? 'Generating...' : 'Generate Business Canvas'}
                    </button>
                </form>

                {error && <p className="text-red-500 bg-red-100 p-3 rounded-lg text-center max-w-3xl mx-auto">{error}</p>}
                
                {isLoading && (
                    <div className="text-center p-8">
                        <div className="flex justify-center"><LoadingSpinner /></div>
                        <p className="mt-2 text-gray-500 dark:text-[#94A3B8]">Tom is drafting your business plan...</p>
                    </div>
                )}

                {canvasData && (
                    <div className="mt-6 space-y-8 animate-fade-in">
                        <div>
                            <h3 className="text-xl font-bold text-center mb-4 text-[#2B2B2B] dark:text-[#E2E8F0]">Business Model Canvas</h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                                <CanvasCard title="Key Partners" items={canvasData.canvas.keyPartners} />
                                <div className="flex flex-col gap-4">
                                    <CanvasCard title="Key Activities" items={canvasData.canvas.keyActivities} />
                                    <CanvasCard title="Key Resources" items={canvasData.canvas.keyResources} />
                                </div>
                                <CanvasCard title="Value Propositions" items={canvasData.canvas.valuePropositions} className="lg:row-span-2" />
                                <div className="flex flex-col gap-4">
                                    <CanvasCard title="Customer Relationships" items={canvasData.canvas.customerRelationships} />
                                    <CanvasCard title="Channels" items={canvasData.canvas.channels} />
                                </div>
                                <CanvasCard title="Customer Segments" items={canvasData.canvas.customerSegments} />
                                <CanvasCard title="Cost Structure" items={canvasData.canvas.costStructure} className="lg:col-span-2" />
                                <CanvasCard title="Revenue Streams" items={canvasData.canvas.revenueStreams} className="lg:col-span-3" />
                            </div>
                        </div>

                        <div>
                            <h3 className="text-xl font-bold text-center mb-4 text-[#2B2B2B] dark:text-[#E2E8F0]">3-Year Financial Projections</h3>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                {canvasData.projections?.map(p => (
                                    <div key={p.year} className="bg-white dark:bg-[#1E1B3A] p-6 rounded-2xl shadow-lg border border-slate-200 dark:border-[#2a274c]">
                                        <h4 className="font-bold text-lg text-center mb-2 text-[#2B2B2B] dark:text-[#E2E8F0]">Year {p.year}</h4>
                                        <p className="text-center text-2xl font-bold text-emerald-500">{p.revenue}</p>
                                        <p className="text-center text-sm text-gray-500 dark:text-gray-400 mb-2">Revenue</p>
                                        <p className="text-center text-lg font-bold text-sky-500">{p.profit}</p>
                                        <p className="text-center text-sm text-gray-500 dark:text-gray-400 mb-4">Profit</p>
                                        <p className="text-xs text-gray-600 dark:text-gray-300"><strong className="font-semibold">Assumptions:</strong> {p.assumptions}</p>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div>
                            <h3 className="text-xl font-bold text-center mb-4 text-[#2B2B2B] dark:text-[#E2E8F0]">Competitive Landscape</h3>
                             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                                {canvasData.competitors?.map(c => (
                                    <div key={c.name} className="bg-white dark:bg-[#1E1B3A] p-6 rounded-2xl shadow-lg border border-slate-200 dark:border-[#2a274c]">
                                        <h4 className="font-bold text-lg text-center mb-4 text-[#2B2B2B] dark:text-[#E2E8F0]">{c.name}</h4>
                                        <p className="font-semibold text-sm text-green-600 dark:text-green-400">Strengths:</p>
                                        <p className="text-sm mb-3 text-gray-700 dark:text-gray-300">{c.strengths}</p>
                                        <p className="font-semibold text-sm text-red-600 dark:text-red-400">Weaknesses:</p>
                                        <p className="text-sm text-gray-700 dark:text-gray-300">{c.weaknesses}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default BusinessCanvas;
