
import React, { useState } from 'react';
import LoadingSpinner from './LoadingSpinner';

interface InputBarProps {
  onSendMessage: (message: string) => void;
  isSessionActive: boolean;
  isConnecting: boolean;
  toggleSession: () => void;
  isSending: boolean;
}

const InputBar: React.FC<InputBarProps> = ({ onSendMessage, isSessionActive, isConnecting, toggleSession, isSending }) => {
  const [text, setText] = useState('');

  const handleSend = () => {
    if (text.trim()) {
      onSendMessage(text.trim());
      setText('');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="sticky bottom-0 left-0 right-0 p-2 sm:p-4 bg-slate-50/80 dark:bg-[#0F0F1C]/80 backdrop-blur-sm">
      <div className="max-w-3xl mx-auto flex items-center gap-2 sm:gap-4 p-2 bg-white dark:bg-[#1E1B3A] rounded-2xl shadow-lg border border-slate-200 dark:border-[#2a274c]">
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Ask your co-founder..."
          className="flex-grow bg-transparent text-[#2B2B2B] dark:text-[#E2E8F0] text-base p-2 focus:outline-none resize-none"
          rows={1}
          disabled={isSending || isSessionActive}
        />
        <button
          onClick={handleSend}
          disabled={isSending || !text.trim() || isSessionActive}
          className="p-3 rounded-xl bg-violet-500 hover:bg-violet-600 disabled:bg-violet-300 disabled:cursor-not-allowed transition-all"
        >
          {isSending ? <div className="w-6 h-6"><LoadingSpinner /></div> : <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>}
        </button>
        <div className="w-px h-8 bg-slate-300 dark:bg-[#2a274c]"></div>
        <button
          onClick={toggleSession}
          disabled={isConnecting}
          className={`p-3 rounded-xl transition-colors ${isSessionActive ? 'bg-red-500 hover:bg-red-600' : 'bg-emerald-500 hover:bg-emerald-600'} text-white disabled:bg-gray-400`}
        >
          {isConnecting ? <div className="w-6 h-6"><LoadingSpinner /></div> : (isSessionActive
            ? <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 10h6" /></svg>
            : <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
          )}
        </button>
      </div>
    </div>
  );
};

export default InputBar;
