import React, { useState } from 'react';
import { generateMarketingStrategy } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';

const MarketingStrategist: React.FC = () => {
    const [idea, setIdea] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [strategy, setStrategy] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!idea.trim() || isLoading) return;

        setIsLoading(true);
        setError(null);
        setStrategy(null);
        
        const statusEl = document.getElementById('aiStatus');
        if (statusEl) statusEl.innerText = '';

        try {
            const resultStrategy = await generateMarketingStrategy(idea);
            setStrategy(resultStrategy);
        } catch (err) {
            setError('An error occurred while generating the marketing strategy.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleDownload = () => {
        if (!strategy) return;
        const blob = new Blob([strategy], { type: 'text/plain;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'marketing-strategy.txt';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    const renderStrategy = (content: string) => {
        const lines = content.split('\n');
        return lines.map((line, index) => {
            if (line.startsWith('**') && line.endsWith('**')) {
                return <h3 key={index} className="text-lg font-bold text-violet-600 dark:text-violet-400 mt-4 mb-2">{line.substring(2, line.length - 2)}</h3>;
            }
            if (line.trim().startsWith('- ')) {
                return <li key={index} className="ml-5 list-disc">{line.trim().substring(2)}</li>;
            }
            if (line.trim().startsWith('📝') || line.trim().startsWith('📈') || line.trim().startsWith('🔑') || line.trim().startsWith('🎯')) {
                 return <p key={index} className="font-semibold mt-3">{line}</p>
            }
            return <p key={index} className="leading-relaxed my-1">{line}</p>;
        });
    };

    return (
        <div className="flex-grow flex flex-col p-4 md:p-6 items-center bg-slate-50 dark:bg-[#0F0F1C] overflow-y-auto">
            <div className="w-full max-w-3xl">
                <div className="text-center mb-8">
                    <h2 className="text-2xl font-bold text-[#2B2B2B] dark:text-[#E2E8F0] mb-2">Marketing Strategist</h2>
                    <p className="text-gray-600 dark:text-[#94A3B8]">Describe your startup idea, and I'll generate a comprehensive marketing plan for you.</p>
                </div>

                <form onSubmit={handleSubmit} className="mb-6">
                    <textarea
                        value={idea}
                        onChange={(e) => setIdea(e.target.value)}
                        placeholder="e.g., A mobile app that uses AI to create personalized workout plans for busy professionals."
                        className="w-full bg-white dark:bg-[#1E1B3A] text-[#2B2B2B] dark:text-[#E2E8F0] text-base p-4 rounded-2xl shadow-lg border border-slate-200 dark:border-[#2a274c] focus:outline-none focus:ring-2 focus:ring-violet-500"
                        rows={4}
                        disabled={isLoading}
                    />
                    <button
                        type="submit"
                        disabled={isLoading || !idea.trim()}
                        className="mt-4 w-full p-4 rounded-xl bg-violet-500 text-white font-bold text-lg hover:bg-violet-600 disabled:bg-violet-300 disabled:cursor-not-allowed transition-all"
                    >
                        {isLoading ? 'Generating Strategy...' : 'Generate Strategy'}
                    </button>
                </form>

                <div id="aiStatus" className="text-center font-bold mt-2 text-gray-600 dark:text-gray-400"></div>

                {error && <p className="text-red-500 bg-red-100 p-3 rounded-lg text-center">{error}</p>}
                
                {isLoading && (
                    <div className="text-center p-8">
                        <div className="flex justify-center"><LoadingSpinner /></div>
                        <p className="mt-2 text-gray-500 dark:text-[#94A3B8]">Tom is crafting your marketing plan...</p>
                    </div>
                )}

                {strategy && (
                    <div className="mt-6 bg-white dark:bg-[#1E1B3A] p-6 rounded-2xl shadow-lg border border-slate-200 dark:border-[#2a274c]">
                        <div className="prose max-w-none text-[#2B2B2B] dark:text-[#E2E8F0]">
                            {renderStrategy(strategy)}
                        </div>
                         <button
                            onClick={handleDownload}
                            className="mt-6 w-full p-3 bg-emerald-500 text-white font-bold rounded-lg shadow-md hover:bg-emerald-600 transition-colors"
                        >
                            Download Plan
                        </button>
                    </div>
                )}
            </div>
        </div>
    );
};

export default MarketingStrategist;