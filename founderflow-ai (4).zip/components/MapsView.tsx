import React, { useState, useRef, useEffect } from 'react';
import { getMapsResponse } from '../services/geminiService';
import type { MapsMessage, GroundingSource } from '../types';
import LoadingSpinner from './LoadingSpinner';

const MapsView: React.FC = () => {
    const [messages, setMessages] = useState<MapsMessage[]>([
        { id: 'intro', role: 'assistant', content: 'Ask me to find places or get information about locations. For more relevant results, allow access to your location.' }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [location, setLocation] = useState<{ latitude: number, longitude: number } | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [mapQuery, setMapQuery] = useState('Googleplex');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleGetLocation = () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    setLocation({
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude,
                    });
                    setMessages(prev => [...prev, { id: 'location-success', role: 'assistant', content: 'Location acquired! Your search results will now be more relevant.' }]);
                },
                () => {
                    setError('Unable to retrieve your location. Please ensure location services are enabled.');
                }
            );
        } else {
            setError('Geolocation is not supported by this browser.');
        }
    };

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        const prompt = input.trim();
        if (!prompt || isLoading) return;

        setIsLoading(true);
        setError(null);
        const userMessage: MapsMessage = { id: Date.now().toString(), role: 'user', content: prompt };
        setMessages(prev => [...prev, userMessage]);
        setInput('');

        try {
            const response = await getMapsResponse(prompt, location ?? undefined);
            const content = response.text;
            const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;

            const sources: GroundingSource[] = groundingChunks
                ?.map((chunk: any) => chunk.maps)
                .filter(Boolean)
                .map((map: any) => ({ uri: map.uri, title: map.title })) ?? [];
            
            const assistantMessage: MapsMessage = {
                id: (Date.now() + 1).toString(),
                role: 'assistant',
                content,
                sources
            };
            setMessages(prev => [...prev, assistantMessage]);
            setMapQuery(prompt);

        } catch (err) {
            setError(err instanceof Error ? err.message : 'An unknown error occurred.');
        } finally {
            setIsLoading(false);
        }
    };
    
    const mapUrl = `https://www.google.com/maps/embed/v1/search?key=${process.env.API_KEY}&q=${encodeURIComponent(mapQuery)}${location ? `&center=${location.latitude},${location.longitude}` : ''}`;

    return (
        <div className="flex-grow flex flex-col md:flex-row h-full overflow-hidden bg-slate-50 dark:bg-[#0F0F1C]">
            <div className="md:w-1/2 h-64 md:h-full flex flex-col">
                 <iframe
                    className="w-full h-full border-none"
                    loading="lazy"
                    allowFullScreen
                    src={mapUrl}>
                </iframe>
            </div>
            <div className="md:w-1/2 flex flex-col h-full">
                <div className="p-4 border-b border-slate-200 dark:border-[#2a274c] text-center">
                    <h2 className="text-xl font-bold text-[#2B2B2B] dark:text-[#E2E8F0]">Location Intelligence</h2>
                     <button onClick={handleGetLocation} className="text-sm text-violet-500 hover:underline">
                        {location ? `📍 Location Set (${location.latitude.toFixed(2)}, ${location.longitude.toFixed(2)})` : 'Get My Location for Better Results'}
                    </button>
                </div>
                <main className="flex-grow overflow-y-auto p-4 md:p-6">
                    <div className="max-w-3xl mx-auto">
                        {messages.map((msg) => (
                            <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} mb-4 animate-fade-in`}>
                                <div className={`p-3 max-w-md shadow-md rounded-lg ${msg.role === 'user' ? 'bg-white dark:bg-violet-600 dark:text-white rounded-br-none' : 'bg-white dark:bg-[#1E1B3A] text-[#2B2B2B] dark:text-[#E2E8F0] rounded-bl-none'}`}>
                                    <p className="text-base leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                                    {msg.sources && msg.sources.length > 0 && (
                                        <div className="mt-2 border-t border-slate-200 dark:border-[#2a274c] pt-2">
                                            <h4 className="text-xs font-bold mb-1">Sources:</h4>
                                            <ul className="space-y-1">
                                                {msg.sources.map(source => (
                                                    <li key={source.uri}>
                                                        <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-xs text-emerald-500 hover:underline">
                                                            {source.title}
                                                        </a>
                                                    </li>
                                                ))}
                                            </ul>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                         {isLoading && (
                            <div className="flex justify-start mb-4">
                                <div className="p-3 max-w-md shadow-md rounded-lg bg-white dark:bg-[#1E1B3A] text-[#2B2B2B] dark:text-[#E2E8F0] rounded-bl-none">
                                    <LoadingSpinner />
                                </div>
                            </div>
                        )}
                        {error && <p className="text-red-500 text-center">{error}</p>}
                        <div ref={messagesEndRef} />
                    </div>
                </main>
                <form onSubmit={handleSendMessage} className="p-2 sm:p-4 bg-slate-50/80 dark:bg-[#0F0F1C]/80 backdrop-blur-sm">
                     <div className="max-w-3xl mx-auto flex items-center gap-2 sm:gap-4 p-2 bg-white dark:bg-[#1E1B3A] rounded-2xl shadow-lg border border-slate-200 dark:border-[#2a274c]">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder="e.g., 'good coffee shops near me'"
                            className="flex-grow bg-transparent text-[#2B2B2B] dark:text-[#E2E8F0] text-base p-2 focus:outline-none"
                            disabled={isLoading}
                        />
                        <button
                            type="submit"
                            disabled={isLoading || !input.trim()}
                            className="p-3 rounded-xl bg-violet-500 hover:bg-violet-600 disabled:bg-violet-300 disabled:cursor-not-allowed transition-all"
                        >
                            {isLoading ? <div className="w-6 h-6"><LoadingSpinner /></div> : <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default MapsView;
