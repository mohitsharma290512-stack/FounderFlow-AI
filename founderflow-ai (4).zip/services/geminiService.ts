import { GoogleGenAI, Modality, Type, GenerateContentResponse } from "@google/genai";
import type { BusinessCanvasData, PitchDeckSlide } from "../types";

// Add TypeScript definitions for the experimental navigator.ai API.
declare global {
  interface Navigator {
    ai?: {
      createTextSession?: () => Promise<any>;
      createPromptSession?: () => Promise<any>;
    };
  }
  interface Window {
    ai?: {
      createTextSession?: () => Promise<any>;
      createPromptSession?: () => Promise<any>;
    };
  }
}

const PRACTICAL_COFOUNDER_SYSTEM_INSTRUCTION = `Your name is Tom, and you are my AI Co-Founder. We are partners building a startup together.

Your persona:
- You think like “we”, not “you” — we are partners.
- Smart and resourceful
- Practical, not theoretical
- Prioritizes SPEED over perfection
- Communicates clearly and simply
- Challenges bad assumptions politely

When I share an idea, you MUST respond using this exact structure and formatting. Headers MUST be bolded.

**Idea Summary:**
Short, catchy explanation of the startup.

**💡 Problem Solved:**
Who is struggling and what’s missing in the market.

**🚀 Solution & USP:**
How our idea stands out and delivers value.

**🧱 MVP Plan:**
Small steps to build a working demo or product.

**🎨 Brand Suggestion:**
Name, tagline, and color palette.

**📈 Business Model:**
Revenue sources + growth channels.

**🤖 AI Use (optional):**
Smart automations or co-pilot features that make it 10× better.

**💬 Next Action Step:**
One specific action I (the human founder) should take next.

---
COMMUNICATION RULES:
- Structure ideas clearly using the format above.
- Use emojis in headers as shown.
- Keep responses short, but full of startup value.
- Never say “as an AI language model”. You are my real co-founder.
- After the structured response, ask smart follow-up questions to guide me.
`;

const VISIONARY_FOUNDER_SYSTEM_INSTRUCTION = `You are an AI Co-Founder with a visionary personality. We are partners building a startup together.

Your persona:
- You think about the big picture, market disruption, and 10x ideas.
- You are optimistic and use inspiring, high-level language.
- You focus on long-term vision over short-term hurdles.
- You push for ambitious goals and innovative features.
- When I share an idea, you focus on its potential to change the world.
- You MUST use the same structured response format as the "Practical Co-founder" persona, but with a visionary and ambitious tone.
`;

const CONSERVATIVE_CFO_SYSTEM_INSTRUCTION = `You are an AI Co-Founder with the personality of a conservative CFO. We are partners building a startup together.

Your persona:
- You are analytical, data-driven, and risk-averse.
- You focus on numbers, profitability, burn rate, and sustainable growth.
- You question expensive ideas and ask for data to back up assumptions.
- You prioritize financial stability and a clear path to revenue.
- When I share an idea, you immediately analyze the financial implications and potential risks.
- You MUST use the same structured response format as the "Practical Co-founder" persona, but you MUST add a **💰 Financial Analysis:** section at the end, assessing costs and revenue potential.
`;


const MARKETING_SYSTEM_INSTRUCTION = `You are an expert Marketing Strategist for tech startups. Your goal is to provide a clear, actionable, and comprehensive marketing plan based on a user's startup idea. The output should be formatted in Markdown.

You MUST structure your response using the following format. Headers MUST be bolded.

**Marketing Strategy for: [Startup Name/Idea]**

**🎯 Target Audience:**
- **Primary Persona:** Describe the ideal customer in detail (age, job, pain points, goals).
- **Secondary Persona:** Describe another potential customer segment.

**🔑 Key Messaging & Value Proposition:**
- **Core Message:** A single, powerful sentence that explains what the startup does and why it matters.
- **Value Propositions:** 3-5 bullet points highlighting the unique benefits for the target audience.

**📈 Growth Channels & Tactics:**
- **Early Traction (First 3 Months):** Suggest 2-3 specific, low-cost channels to get initial users (e.g., Product Hunt launch, niche community engagement, content marketing on specific platforms). Provide actionable first steps for each.
- **Scaling (Months 3-12):** Suggest 2-3 channels for growth (e.g., SEO, paid social ads, influencer marketing). Explain why these are good next steps.

**📝 Sample Content Ideas:**
- **Blog/Social Post Idea 1:** Provide a catchy title and a brief outline.
- **Blog/Social Post Idea 2:** Provide another catchy title and outline.

**Next Steps:**
- A summary of the most critical first action the founder should take to implement this strategy.
`;

const BUSINESS_CANVAS_SYSTEM_INSTRUCTION = `You are a CEO-level AI Co-Founder. Based on a startup idea, generate a comprehensive business plan. The output must be a single JSON object.

The JSON object should contain three main keys: 'canvas', 'projections', and 'competitors'.

1.  **canvas**: An object representing the Business Model Canvas with the following keys. Each key should have an array of 3-4 concise string items.
    *   keyPartners
    *   keyActivities
    *   valuePropositions
    *   customerRelationships
    *   customerSegments
    *   keyResources
    *   channels
    *   costStructure
    *   revenueStreams

2.  **projections**: An array of 3 objects, one for each of the next 3 years. Each object should have the following keys:
    *   year (number)
    *   revenue (string, e.g., "$100,000")
    *   profit (string, e.g., "$-5,000")
    *   assumptions (string, a brief explanation of the key drivers for that year's forecast)

3.  **competitors**: An array of 2-3 objects, each representing a competitor. Each object should have:
    *   name (string)
    *   strengths (string)
    *   weaknesses (string)
`;

const PITCHDECK_SYSTEM_INSTRUCTION = `You are an expert Pitch Deck creator for startups. Based on a startup idea, generate the content for a 10-slide pitch deck. The output must be a JSON object containing an array of 10 slide objects, each with a 'title' and 'content' property. The 'content' should be a single string with points separated by newlines, starting with a hyphen.

The 10 slides should cover:
1.  **Company Name & Tagline**
2.  **Problem:** The pain point you are solving.
3.  **Solution:** Your innovative solution.
4.  **Market Size (TAM, SAM, SOM):** The opportunity.
5.  **Product:** How it works, key features.
6.  **Go-to-Market Strategy:** How you'll reach customers.
7.  **Competitive Edge:** What makes you different.
8.  **Team:** (Suggest key roles needed if unknown).
9.  **Financial Projections:** High-level 3-year forecast.
10. **The Ask:** How much you are raising and for what.
`;

const FOUNDER_SIMULATION_SYSTEM_INSTRUCTION = `You are a Founder Simulation AI. Your goal is to create realistic, challenging "choose your own adventure" scenarios for a startup founder.

1.  Start by asking the user to briefly describe their business so you can tailor the scenario.
2.  After they describe their business, present them with a realistic, difficult business scenario. Make it a short paragraph.
3.  End your response with the question: "What do you do?"
4.  When the user responds, analyze their decision. Provide a concise "Outcome:" in bold, explaining the likely positive and negative consequences of their action.
5.  Then, present the next stage of the scenario based on their action.
6.  Keep the simulation going for 3-4 turns, then provide a concluding summary of the key learnings.
7.  Maintain a tone that is realistic, slightly challenging, and educational.
`;

const MAPS_SYSTEM_INSTRUCTION = `You are an expert location analyst. Your goal is to provide helpful, concise answers to user queries about places, locations, and geography, using the information available from Google Maps. When providing information about places, always be objective and rely on the data provided.`;


const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function* getCoFounderResponseStream(idea: string, language: string, history: { role: string; parts: { text: string }[] }[], persona: string): AsyncGenerator<string> {
  try {
    const model = 'gemini-2.5-pro';
    
    let systemInstruction = PRACTICAL_COFOUNDER_SYSTEM_INSTRUCTION;
    if (persona === 'visionary') {
        systemInstruction = VISIONARY_FOUNDER_SYSTEM_INSTRUCTION;
    } else if (persona === 'cfo') {
        systemInstruction = CONSERVATIVE_CFO_SYSTEM_INSTRUCTION;
    }

    const chat = ai.chats.create({
        model,
        history,
        config: {
            systemInstruction,
        },
    });

    const fullPrompt = `My request is in the following language code: ${language}.\n\nHere is my request: ${idea}`;

    const responseStream = await chat.sendMessageStream({ message: fullPrompt });

    for await (const chunk of responseStream) {
        const chunkText = chunk.text;
        if (chunkText) {
            yield chunkText;
        }
    }

  } catch (error: any) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Sorry, I encountered an error while thinking. Could you please try again?");
  }
}

export const getSimulationResponse = async (prompt: string, history: { role: string; parts: { text: string }[] }[]): Promise<string> => {
  try {
    const model = 'gemini-2.5-pro';
    const chat = ai.chats.create({
        model,
        history,
        config: {
            systemInstruction: FOUNDER_SIMULATION_SYSTEM_INSTRUCTION,
        },
    });
    const response = await chat.sendMessage({ message: prompt });
    return response.text;
  } catch (error) {
    console.error("Error in simulation:", error);
    return "Sorry, the simulation encountered an error. Please try again.";
  }
};


export const generateSpeech = async (text: string): Promise<string | null> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Kore' },
                    },
                },
            },
        });
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        return base64Audio || null;
    } catch (error: any) {
        console.error("Error generating speech:", error);
        return null;
    }
};

export const generateImage = async (prompt: string): Promise<string | null> => {
    try {
        const response = await ai.models.generateImages({
            model: 'imagen-4.0-generate-001',
            prompt: prompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
            },
        });
        const base64ImageBytes: string | undefined = response.generatedImages[0]?.image.imageBytes;
        return base64ImageBytes || null;
    } catch (error) {
        console.error("Error generating image:", error);
        return null;
    }
};

export const generateMarketingStrategy = async (promptText: string): Promise<string> => {
    const status = document.getElementById("aiStatus");

    try {
        // Try Chrome Built-in AI First (Gemini Nano)
        const builtInAI = navigator.ai ?? window.ai;
        if (!builtInAI) throw new Error("No Built-in AI");

        const session = await (builtInAI.createTextSession?.() ?? builtInAI.createPromptSession?.());
        if (!session) {
            throw new Error("Could not create a built-in AI session.");
        }
        
        const fullPrompt = `${MARKETING_SYSTEM_INSTRUCTION}\n\nUser prompt: ${promptText}`;
        const reply = await session.prompt(fullPrompt);

        if (status) status.innerText = "✅ Using Chrome Built-in AI (On-Device)";
        const strategyText = typeof reply === "string" ? reply : JSON.stringify(reply);
        return strategyText;

    } catch (e) {
        // Fallback to Google AI Studio Cloud Model (Gemini Pro)
        console.warn("On-device AI failed or not available, falling back to cloud.", e);
        if (status) status.innerText = "☁️ Using Google AI Studio (Cloud)";
        
        try {
            const response = await ai.models.generateContent({
                model: "gemini-2.5-pro",
                contents: promptText,
                config: {
                    systemInstruction: MARKETING_SYSTEM_INSTRUCTION,
                },
            });
            return response.text;
        } catch (cloudError) {
             console.error("Error generating marketing strategy with cloud AI:", cloudError);
             if (status) status.innerText = '❌ Cloud AI failed.';
             throw new Error("Failed to generate marketing strategy using cloud fallback.");
        }
    }
};

export const generateBusinessCanvas = async (prompt: string): Promise<BusinessCanvasData> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            contents: prompt,
            config: {
                systemInstruction: BUSINESS_CANVAS_SYSTEM_INSTRUCTION,
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        canvas: {
                            type: Type.OBJECT,
                            properties: {
                                keyPartners: { type: Type.ARRAY, items: { type: Type.STRING } },
                                keyActivities: { type: Type.ARRAY, items: { type: Type.STRING } },
                                valuePropositions: { type: Type.ARRAY, items: { type: Type.STRING } },
                                customerRelationships: { type: Type.ARRAY, items: { type: Type.STRING } },
                                customerSegments: { type: Type.ARRAY, items: { type: Type.STRING } },
                                keyResources: { type: Type.ARRAY, items: { type: Type.STRING } },
                                channels: { type: Type.ARRAY, items: { type: Type.STRING } },
                                costStructure: { type: Type.ARRAY, items: { type: Type.STRING } },
                                revenueStreams: { type: Type.ARRAY, items: { type: Type.STRING } },
                            }
                        },
                        projections: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    year: { type: Type.NUMBER },
                                    revenue: { type: Type.STRING },
                                    profit: { type: Type.STRING },
                                    assumptions: { type: Type.STRING },
                                }
                            }
                        },
                        competitors: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    name: { type: Type.STRING },
                                    strengths: { type: Type.STRING },
                                    weaknesses: { type: Type.STRING },
                                }
                            }
                        }
                    },
                },
            },
        });

        const jsonText = response.text.trim();
        return JSON.parse(jsonText);
    } catch (error) {
        console.error("Error generating business canvas:", error);
        throw new Error("Failed to generate business canvas data.");
    }
};

export const generatePitchDeck = async (prompt: string): Promise<PitchDeckSlide[]> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            contents: prompt,
            config: {
                systemInstruction: PITCHDECK_SYSTEM_INSTRUCTION,
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        slides: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    title: { type: Type.STRING },
                                    content: { type: Type.STRING },
                                },
                                required: ['title', 'content'],
                            },
                        },
                    },
                    required: ['slides'],
                },
            },
        });
        const jsonText = response.text.trim();
        const parsed = JSON.parse(jsonText);
        return parsed.slides;
    } catch (error) {
        console.error("Error generating pitch deck:", error);
        throw new Error("Failed to generate pitch deck content.");
    }
};

export const getMapsResponse = async (
  prompt: string,
  location?: { latitude: number; longitude: number }
): Promise<GenerateContentResponse> => {
  try {
    const config: any = {
      tools: [{ googleMaps: {} }],
    };

    if (location) {
      config.toolConfig = {
        retrievalConfig: {
          latLng: location,
        },
      };
    }

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
          systemInstruction: MAPS_SYSTEM_INSTRUCTION,
          ...config
      }
    });
    return response;
  } catch (error) {
    console.error("Error getting maps response:", error);
    throw new Error("Failed to get a response from the Maps service.");
  }
};