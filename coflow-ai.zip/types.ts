// FIX: Add Feature enum to be used in constants.tsx
export enum Feature {
  Blueprint = 'BLUEPRINT',
  Competitors = 'COMPETITORS',
  MVP = 'MVP',
  PitchDeck = 'PITCH_DECK',
  Coach = 'COACH',
  MarketingTricks = 'MARKETING_TRICKS',
  RATE_MY_IDEA = 'RATE_MY_IDEA',
}

export interface CoFlowPlan {
  startupName: string;
  problemSummary: string;
  proposedSolution: string;
  targetAudience: string;
  insight: string;
  mvpPlan: {
    phase1: string[];
    phase2: string[];
    phase3: string[];
  };
  techStack: string[];
  goToMarketStrategy: string[];
  monetizationStrategy: string;
  brandingTheme: string;
}