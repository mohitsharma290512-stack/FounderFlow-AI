import React from 'react';
import { Feature } from './types';

interface FeatureInfo {
  id: Feature;
  name: string;
  description: string;
  // FIX: Use a more specific React.ReactElement type for SVG icons to ensure proper typing for operations like React.cloneElement.
  icon: React.ReactElement<React.SVGProps<SVGSVGElement>>;
}

export const FEATURES: FeatureInfo[] = [
  {
    id: Feature.Blueprint,
    name: 'Startup Blueprint',
    description: 'Generate a foundational business plan.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
        <defs>
          <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{stopColor: '#9EE7F9', stopOpacity: 1}} />
            <stop offset="100%" style={{stopColor: '#00E6C3', stopOpacity: 1}} />
          </linearGradient>
        </defs>
        <path d="M12 21H5C4.46957 21 3.96086 20.7893 3.58579 20.4142C3.21071 20.0391 3 19.5304 3 19V5C3 4.46957 3.21071 3.96086 3.58579 3.58579C3.96086 3.21071 4.46957 3 5 3H19C19.5304 3 20.0391 3.21071 20.4142 3.58579C20.7893 3.96086 21 4.46957 21 5V12" stroke="url(#grad1)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M7 8H17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M7 12H13" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M16 21V15" stroke="url(#grad1)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M19 18H13" stroke="url(#grad1)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
  },
  {
    id: Feature.Competitors,
    name: 'Competitive Landscape',
    description: 'Analyze competitors and find your edge.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
        <defs>
            <linearGradient id="grad2" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style={{stopColor: '#9EE7F9', stopOpacity: 1}} />
                <stop offset="100%" style={{stopColor: '#00E6C3', stopOpacity: 1}} />
            </linearGradient>
        </defs>
        <path d="M15.153 19.347A8 8 0 1 1 20 12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M12 12L20 4" stroke="url(#grad2)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M15 4H20V9" stroke="url(#grad2)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 21C16.9706 21 21 16.9706 21 12" stroke="url(#grad2)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="2 6" opacity="0.5"/>
      </svg>
    ),
  },
  {
    id: Feature.MVP,
    name: 'Instant MVP Builder',
    description: 'Create a 4-week product roadmap.',
    icon: (
       <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
        <defs>
          <linearGradient id="grad3" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{stopColor: '#9EE7F9', stopOpacity: 1}} />
            <stop offset="100%" style={{stopColor: '#00E6C3', stopOpacity: 1}} />
          </linearGradient>
        </defs>
        <path d="M21 15C21 16.0274 20.7936 17.034 20.4017 17.9687C19.2483 20.6861 16.2997 22.5 12.875 22.5C9.45028 22.5 6.50174 20.6861 5.34831 17.9687C5.20636 17.654 5.09341 17.3276 5 17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M15.9999 12C17.6567 12 18.9999 10.6569 18.9999 9C18.9999 7.34315 17.6567 6 15.9999 6C14.343 6 12.9999 7.34315 12.9999 9C12.9999 10.6569 14.343 12 15.9999 12Z" stroke="url(#grad3)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M21.5 10.5L20 12L18.5 10.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M12.5 4.5L11 6L9.5 4.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M16 3V1.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M7 12L7 2L17 2L17 4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
      </svg>
    ),
  },
  {
    id: Feature.PitchDeck,
    name: 'Pitch Deck Generator',
    description: 'Structure your investor presentation.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
        <defs>
          <linearGradient id="grad4" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{stopColor: '#9EE7F9', stopOpacity: 1}} />
            <stop offset="100%" style={{stopColor: '#00E6C3', stopOpacity: 1}} />
          </linearGradient>
        </defs>
        <path d="M20 3H4C3.44772 3 3 3.44772 3 4V16C3 16.5523 3.44772 17 4 17H20C20.5523 17 21 16.5523 21 16V4C21 3.44772 20.5523 3 20 3Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M10 21H14" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M12 17V21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M8 8L12 12L16 8" stroke="url(#grad4)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
    ),
  },
  {
    id: Feature.Coach,
    name: 'Daily Startup Coach',
    description: 'Get daily tasks to stay on track.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
        <defs>
          <linearGradient id="grad5" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{stopColor: '#9EE7F9', stopOpacity: 1}} />
            <stop offset="100%" style={{stopColor: '#00E6C3', stopOpacity: 1}} />
          </linearGradient>
        </defs>
        <path d="M16 22H8C4.5 22 3 20 3 17V7C3 4 4.5 2 8 2H16C19.5 2 21 4 21 7V17C21 20 19.5 22 16 22Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M15 7L9 13L11 15L17 9L15 7Z" stroke="url(#grad5)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M7 17H12" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
      </svg>
    ),
  },
  {
    id: Feature.MarketingTricks,
    name: 'Marketing Tricks',
    description: 'Discover creative growth strategies.',
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
        <defs>
          <linearGradient id="grad6" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{stopColor: '#9EE7F9', stopOpacity: 1}} />
            <stop offset="100%" style={{stopColor: '#00E6C3', stopOpacity: 1}} />
          </linearGradient>
        </defs>
        <path d="M12 21C16.9706 21 21 16.9706 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12C3 16.9706 7.02944 21 12 21Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M15 9C15 10.6569 13.6569 12 12 12C10.3431 12 9 10.6569 9 9C9 7.34315 10.3431 6 12 6C13.6569 6 15 7.34315 15 9Z" stroke="url(#grad6)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 12V21" stroke="url(#grad6)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 6V3" stroke="url(#grad6)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M9.17188 15.8281L3.51472 21.4853" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M20.4853 3.51472L14.8281 9.17188" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
      </svg>
    ),
  },
  {
    id: Feature.RATE_MY_IDEA,
    name: 'Rate My Startup Idea',
    description: "Get an AI-driven rating on your idea's potential.",
    icon: (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
        <defs>
          <linearGradient id="grad7" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{stopColor: '#9EE7F9', stopOpacity: 1}} />
            <stop offset="100%" style={{stopColor: '#00E6C3', stopOpacity: 1}} />
          </linearGradient>
        </defs>
        <path d="M12 21C16.9706 21 21 16.9706 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12C3 16.9706 7.02944 21 12 21Z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
        <path d="M12 12L16.2426 7.75736" stroke="url(#grad7)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 7H12.01" stroke="url(#grad7)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M17.6568 12H17.6668" stroke="url(#grad7)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M6.34315 12H6.35315" stroke="url(#grad7)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
    ),
  }
];