import React from 'react';
import type { CoFlowPlan } from '../types';

const Section: React.FC<{ title: string; children: React.ReactNode; className?: string }> = ({ title, children, className = '' }) => (
  <div className={`mb-8 last:mb-0 w-full ${className}`}>
    <h3 className="text-xl font-bold text-white mb-4 tracking-wide relative pb-2 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-16 after:h-0.5 after:bg-gradient-to-r after:from-[#6953F0] after:to-transparent">{title}</h3>
    <div className="text-[#B9C4D7] space-y-3 leading-relaxed">{children}</div>
  </div>
);

const BulletList: React.FC<{ items: string[] }> = ({ items }) => (
    <ul className="list-disc list-inside space-y-2 p-4 bg-black/20 rounded-lg border border-white/10">
      {items.map((item, index) => <li key={index}>{item}</li>)}
    </ul>
);

const TextBox: React.FC<{ text: string }> = ({ text }) => (
    <p className="p-4 bg-black/20 rounded-lg border border-white/10">{text}</p>
);

export const CoFlowPlanDisplay: React.FC<{ data: CoFlowPlan }> = ({ data }) => (
  <div className="space-y-8">
    <header className="text-center border-b border-white/10 pb-6">
        <h2 className="text-4xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-300">🚀 {data.startupName}</h2>
    </header>

    <Section title="🎯 Problem Summary">
      <TextBox text={data.problemSummary} />
    </Section>
    
    <Section title="✅ Proposed Solution">
      <TextBox text={data.proposedSolution} />
    </Section>
    
    <Section title="👥 Target Audience">
      <TextBox text={data.targetAudience} />
    </Section>

    <Section title="🧠 Insight (Why Now / Why it Matters)">
      <TextBox text={data.insight} />
    </Section>
    
    <Section title="🏗️ MVP Plan">
        <div className="space-y-4">
            <div>
                <h4 className="font-semibold text-[#00E0A9] mb-2">Phase 1 (1 Week): Core Validation</h4>
                <BulletList items={data.mvpPlan.phase1} />
            </div>
            <div>
                <h4 className="font-semibold text-[#00E0A9] mb-2">Phase 2 (2–4 Weeks): Retention Features</h4>
                <BulletList items={data.mvpPlan.phase2} />
            </div>
            <div>
                <h4 className="font-semibold text-[#00E0A9] mb-2">Phase 3 (Scale): Growth & Defensibility</h4>
                <BulletList items={data.mvpPlan.phase3} />
            </div>
        </div>
    </Section>
    
    <Section title="🛠️ Recommended Tech Stack">
      <BulletList items={data.techStack} />
    </Section>

    <Section title="📈 Go-To-Market Strategy">
      <BulletList items={data.goToMarketStrategy} />
    </Section>

    <Section title="💰 Monetization Strategy">
      <TextBox text={data.monetizationStrategy} />
    </Section>

    <Section title="🎨 Branding & UI Theme Recommendation">
      <TextBox text={data.brandingTheme} />
    </Section>
  </div>
);