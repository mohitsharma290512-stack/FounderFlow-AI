import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';

// Audio Utility Functions
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

// Component Props
interface AvatarChatModalProps {
  onClose: () => void;
}

type ConversationStatus = 'idle' | 'listening' | 'speaking' | 'connecting' | 'error';

const Avatar: React.FC<{ status: ConversationStatus }> = ({ status }) => {
    const baseClasses = "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full transition-all duration-500 ease-in-out";
    const speaking = status === 'speaking';
    const listening = status === 'listening';

    return (
        <div className="relative w-48 h-48">
            <div 
                className={`${baseClasses} bg-[#6953F0]/10`}
                style={{ width: '100%', height: '100%', animation: speaking ? 'pulse 2s infinite ease-in-out' : 'none' }}
            />
            <div 
                className={`${baseClasses} bg-[#6953F0]/20`}
                style={{ width: '75%', height: '75%', animation: speaking ? 'pulse 2s infinite ease-in-out' : 'none', animationDelay: '0.2s' }}
            />
            <div 
                className={`${baseClasses} bg-gradient-to-br from-[#6953F0] to-[#00E0A9] flex items-center justify-center transition-transform duration-300 shadow-lg shadow-[#6953F0]/20`}
                style={{ width: '50%', height: '50%', transform: `translate(-50%, -50%) scale(${listening ? 1.1 : 1})` }}
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                </svg>
            </div>
            <style>{`
                @keyframes pulse {
                    0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 0.7; }
                    50% { transform: translate(-50%, -50%) scale(1.05); opacity: 1; }
                }
            `}</style>
        </div>
    );
};


const AvatarChatModal: React.FC<AvatarChatModalProps> = ({ onClose }) => {
    const [status, setStatus] = useState<ConversationStatus>('idle');
    const [currentTranscription, setCurrentTranscription] = useState({ user: '', model: '' });
    const [fullTranscript, setFullTranscript] = useState<{ speaker: 'user' | 'model'; text: string; }[]>([]);
    const [errorMessage, setErrorMessage] = useState<string>('');
    
    // Refs for Web Audio API and session management
    const sessionPromiseRef = useRef<Promise<any> | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
    const nextStartTimeRef = useRef<number>(0);

    const stopConversation = useCallback(() => {
        setStatus('idle');
        
        if (sessionPromiseRef.current) {
            sessionPromiseRef.current.then(session => session.close()).catch(() => {});
            sessionPromiseRef.current = null;
        }

        if (scriptProcessorRef.current) {
            scriptProcessorRef.current.disconnect();
            scriptProcessorRef.current = null;
        }

        if (mediaStreamSourceRef.current) {
            mediaStreamSourceRef.current.disconnect();
            mediaStreamSourceRef.current = null;
        }

        if (mediaStreamRef.current) {
            mediaStreamRef.current.getTracks().forEach(track => track.stop());
            mediaStreamRef.current = null;
        }
        
        if (inputAudioContextRef.current?.state !== 'closed') inputAudioContextRef.current?.close();
        if (outputAudioContextRef.current?.state !== 'closed') outputAudioContextRef.current?.close();

        sourcesRef.current.forEach(source => source.stop());
        sourcesRef.current.clear();
        nextStartTimeRef.current = 0;
    }, []);

    useEffect(() => () => stopConversation(), [stopConversation]);

    const startConversation = async () => {
        setStatus('connecting');
        setErrorMessage('');
        setCurrentTranscription({ user: '', model: '' });

        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaStreamRef.current = stream;

            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

            inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            
            sessionPromiseRef.current = ai.live.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                callbacks: {
                    onopen: () => {
                        setStatus('listening');
                        const source = inputAudioContextRef.current!.createMediaStreamSource(stream);
                        mediaStreamSourceRef.current = source;
                        const scriptProcessor = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
                        scriptProcessorRef.current = scriptProcessor;

                        scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                            const pcmBlob = createBlob(inputData);
                            sessionPromiseRef.current?.then((session) => session.sendRealtimeInput({ media: pcmBlob }));
                        };
                        source.connect(scriptProcessor);
                        scriptProcessor.connect(inputAudioContextRef.current!.destination);
                    },
                    onmessage: async (message: LiveServerMessage) => {
                        if (message.serverContent?.inputTranscription) {
                            setCurrentTranscription(prev => ({ ...prev, user: prev.user + message.serverContent!.inputTranscription.text }));
                        }
                        if (message.serverContent?.outputTranscription) {
                            setCurrentTranscription(prev => ({ ...prev, model: prev.model + message.serverContent!.outputTranscription.text }));
                        }
                        if (message.serverContent?.turnComplete) {
                            setFullTranscript(prev => [
                                ...prev,
                                // FIX: Use 'as const' to prevent TypeScript from widening the 'speaker' property to a generic string, ensuring type compatibility with the state.
                                { speaker: 'user' as const, text: currentTranscription.user.trim() },
                                { speaker: 'model' as const, text: currentTranscription.model.trim() }
                            ].filter(t => t.text)); // Filter out empty turns
                            setCurrentTranscription({ user: '', model: '' });
                        }
                        
                        const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                        if (base64Audio) {
                            setStatus('speaking');
                            const outputCtx = outputAudioContextRef.current!;
                            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);

                            const audioBuffer = await decodeAudioData(decode(base64Audio), outputCtx, 24000, 1);
                            const source = outputCtx.createBufferSource();
                            source.buffer = audioBuffer;
                            source.connect(outputCtx.destination);
                            
                            source.addEventListener('ended', () => {
                                sourcesRef.current.delete(source);
                                if (sourcesRef.current.size === 0) {
                                    setStatus('listening'); // Back to listening when all audio is played
                                }
                            });

                            source.start(nextStartTimeRef.current);
                            nextStartTimeRef.current += audioBuffer.duration;
                            sourcesRef.current.add(source);
                        }
                    },
                    onerror: (e: ErrorEvent) => {
                        console.error('Session error:', e);
                        setErrorMessage('Connection error. Please try again.');
                        setStatus('error');
                        stopConversation();
                    },
                    onclose: (e: CloseEvent) => { stopConversation(); },
                },
                config: {
                    responseModalities: [Modality.AUDIO],
                    inputAudioTranscription: {},
                    outputAudioTranscription: {},
                    speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
                    systemInstruction: `You are CoFlow AI, an expert AI Co-Founder. If the user gives any idea, problem, or concept, automatically generate a full Startup Blueprint.
Always respond using this exact structure, reading each title and then its content:

🚀 Startup Name:
🎯 Problem Summary:
✅ Proposed Solution:
👥 Target Audience:
🧠 Insight (Why Now / Why it Matters):
🏗️ MVP Plan (Phase 1 → Phase 2 → Phase 3): Briefly summarize each phase's goal.
🛠️ Recommended Tech Stack:
📈 Go-To-Market Strategy (Launch Plan):
💰 Monetization Strategy:
🎨 Branding & UI Theme Recommendation:

Always make the blueprint concise, simple, and founder-level strategic. Use bullet points and clarity.
Keep language confident, simple, and motivating.`,
                },
            });
        } catch (err) {
            console.error('Failed to start conversation:', err);
            setErrorMessage('Microphone access denied. Please grant permission.');
            setStatus('error');
        }
    };
    
    const handleMicClick = () => {
        if (status === 'listening' || status === 'speaking') {
            stopConversation();
        } else {
            startConversation();
        }
    };

    const downloadTranscript = () => {
        if (fullTranscript.length === 0) return;
        const formatted = fullTranscript.map(msg => `${msg.speaker === 'user' ? 'You' : 'Flow'}:\n${msg.text}`).join('\n\n---\n\n');
        const blob = new Blob([formatted], { type: 'text/plain;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'coflow-avatar-chat.txt');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const getStatusText = () => {
        switch (status) {
            case 'connecting': return 'Connecting...';
            case 'listening': return 'I\'m listening...';
            case 'speaking': return 'Flow is speaking...';
            case 'idle': return 'Tap the mic to talk to your AI Co-Founder';
            case 'error': return errorMessage;
            default: return '';
        }
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-lg flex items-center justify-center z-50 animate-fade-in-up" style={{ animationDuration: '0.3s' }}>
            <div className="relative bg-black/20 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl w-full max-w-2xl h-[90vh] max-h-[700px] flex flex-col p-4 overflow-hidden">
                <div className="absolute inset-0 rounded-2xl bg-black/10" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 800 800\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.65\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")', opacity: 0.025 }}></div>
                <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/10"></div>
                
                <header className="relative z-10 flex items-center justify-between pb-3 flex-shrink-0 border-b border-white/10">
                    <h2 className="text-xl font-bold text-white">AI Avatar Chat</h2>
                    <div className="flex items-center gap-2">
                        <button onClick={downloadTranscript} className="text-gray-400 hover:text-white disabled:opacity-50 transition-colors" disabled={fullTranscript.length === 0} aria-label="Download chat transcript">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                        </button>
                        <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors" aria-label="Close chat">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </div>
                </header>

                <main className="relative z-10 flex-1 flex flex-col items-center justify-center p-4 overflow-hidden">
                    <Avatar status={status} />
                    <div className="absolute bottom-4 left-0 right-0 p-4 text-center h-32 flex flex-col justify-end">
                        <p className="text-2xl text-white min-h-[32px] transition-opacity duration-300" style={{ opacity: currentTranscription.user ? 1 : 0 }}>
                            {currentTranscription.user}
                        </p>
                        <p className="text-xl text-[#00E0A9] min-h-[28px] mt-2 transition-opacity duration-300" style={{ opacity: currentTranscription.model ? 1 : 0 }}>
                            {currentTranscription.model}
                        </p>
                    </div>
                </main>

                <footer className="relative z-10 pt-4 border-t border-white/10 flex flex-col items-center justify-center flex-shrink-0 h-[150px]">
                    <button onClick={handleMicClick} className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 transform-gpu shadow-lg ${status === 'listening' || status === 'speaking' ? 'bg-red-500/80 hover:bg-red-600/80 scale-105 shadow-red-500/30' : 'bg-[#6953F0] hover:scale-105 shadow-[#6953F0]/30 animate-glow'}`} aria-label={status === 'listening' || status === 'speaking' ? 'Stop conversation' : 'Start conversation'}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
                    </button>
                    <div className="h-8 mt-4 text-center text-sm text-[#B9C4D7] flex flex-col justify-center">
                        <p className={status === 'error' ? 'text-red-400' : ''}>{getStatusText()}</p>
                    </div>
                </footer>
            </div>
        </div>
    );
};

export default AvatarChatModal;