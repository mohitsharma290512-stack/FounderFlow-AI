import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';

// Audio Utility Functions (as per guidelines)
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function createBlob(data: Float32Array): Blob {
  const l = data.length;
  const int16 = new Int16Array(l);
  for (let i = 0; i < l; i++) {
    int16[i] = data[i] * 32768;
  }
  return {
    data: encode(new Uint8Array(int16.buffer)),
    mimeType: 'audio/pcm;rate=16000',
  };
}

// Component Props
interface ChatModalProps {
  onClose: () => void;
}

interface ChatMessage {
    id: string;
    speaker: 'user' | 'model';
    text: string;
    timestamp: string;
}

const ChatModal: React.FC<ChatModalProps> = ({ onClose }) => {
    const [status, setStatus] = useState<'idle' | 'listening' | 'connecting' | 'error'>('idle');
    const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
    const [errorMessage, setErrorMessage] = useState<string>('');
    const [isTyping, setIsTyping] = useState<boolean>(false);
    const [copiedId, setCopiedId] = useState<string | null>(null);

    const sessionPromiseRef = useRef<Promise<any> | null>(null);
    const mediaStreamRef = useRef<MediaStream | null>(null);
    const inputAudioContextRef = useRef<AudioContext | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
    const mediaStreamSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
    const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
    const nextStartTimeRef = useRef<number>(0);

    const currentInputTranscriptionRef = useRef<string>('');
    const currentOutputTranscriptionRef = useRef<string>('');
    const chatHistoryEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        chatHistoryEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [chatHistory, isTyping]);

    const stopConversation = useCallback(() => {
        setStatus('idle');
        setIsTyping(false);
        if (sessionPromiseRef.current) {
            sessionPromiseRef.current.then(session => session.close());
            sessionPromiseRef.current = null;
        }
        if (scriptProcessorRef.current) {
            scriptProcessorRef.current.disconnect();
            scriptProcessorRef.current = null;
        }
        if (mediaStreamSourceRef.current) {
            mediaStreamSourceRef.current.disconnect();
            mediaStreamSourceRef.current = null;
        }
        if (mediaStreamRef.current) {
            mediaStreamRef.current.getTracks().forEach(track => track.stop());
            mediaStreamRef.current = null;
        }
        if (inputAudioContextRef.current && inputAudioContextRef.current.state !== 'closed') {
            inputAudioContextRef.current.close();
        }
        if (outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
            outputAudioContextRef.current.close();
        }
        sourcesRef.current.forEach(source => source.stop());
        sourcesRef.current.clear();
        nextStartTimeRef.current = 0;
    }, []);

    useEffect(() => () => stopConversation(), [stopConversation]);

    const startConversation = async () => {
        setStatus('connecting');
        setErrorMessage('');
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            mediaStreamRef.current = stream;
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
            inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
            outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
            
            sessionPromiseRef.current = ai.live.connect({
                model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                callbacks: {
                    onopen: () => {
                        setStatus('listening');
                        const source = inputAudioContextRef.current!.createMediaStreamSource(stream);
                        mediaStreamSourceRef.current = source;
                        const scriptProcessor = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
                        scriptProcessorRef.current = scriptProcessor;
                        scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                            const pcmBlob = createBlob(inputData);
                            if(sessionPromiseRef.current) {
                                sessionPromiseRef.current.then((session) => {
                                    session.sendRealtimeInput({ media: pcmBlob });
                                });
                            }
                        };
                        source.connect(scriptProcessor);
                        scriptProcessor.connect(inputAudioContextRef.current!.destination);
                    },
                    onmessage: async (message: LiveServerMessage) => {
                        if (message.serverContent?.outputTranscription) {
                            if (!isTyping) setIsTyping(true);
                            currentOutputTranscriptionRef.current += message.serverContent.outputTranscription.text;
                        }
                        if (message.serverContent?.inputTranscription) {
                            currentInputTranscriptionRef.current += message.serverContent.inputTranscription.text;
                        }
                        if (message.serverContent?.turnComplete) {
                            setIsTyping(false);
                            const fullInput = currentInputTranscriptionRef.current.trim();
                            const fullOutput = currentOutputTranscriptionRef.current.trim();
                            const newMessages: ChatMessage[] = [];
                            const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                            if (fullInput) newMessages.push({ speaker: 'user', text: fullInput, id: `user-${Date.now()}`, timestamp });
                            if (fullOutput) newMessages.push({ speaker: 'model', text: fullOutput, id: `model-${Date.now()}`, timestamp });
                            if (newMessages.length > 0) setChatHistory(prev => [...prev, ...newMessages]);
                            currentInputTranscriptionRef.current = '';
                            currentOutputTranscriptionRef.current = '';
                        }
                        const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
                        if (base64Audio) {
                            const outputCtx = outputAudioContextRef.current!;
                            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
                            const audioBuffer = await decodeAudioData(decode(base64Audio), outputCtx, 24000, 1);
                            const source = outputCtx.createBufferSource();
                            source.buffer = audioBuffer;
                            source.connect(outputCtx.destination);
                            source.addEventListener('ended', () => sourcesRef.current.delete(source));
                            source.start(nextStartTimeRef.current);
                            nextStartTimeRef.current += audioBuffer.duration;
                            sourcesRef.current.add(source);
                        }
                    },
                    onerror: (e: ErrorEvent) => {
                        console.error('Session error:', e);
                        setErrorMessage('A connection error occurred. Please try again.');
                        setStatus('error');
                        stopConversation();
                    },
                    onclose: (e: CloseEvent) => {},
                },
                config: {
                    responseModalities: [Modality.AUDIO],
                    inputAudioTranscription: {},
                    outputAudioTranscription: {},
                    speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
                    systemInstruction: 'You are a friendly and helpful AI Co-Founder for startup planning, fluent in both English and Hindi. You must automatically detect the user\'s spoken language (English or Hindi) and consistently respond in that same language throughout the conversation.',
                },
            });
        } catch (err) {
            console.error('Failed to start conversation:', err);
            setErrorMessage('Could not access microphone. Please grant permission and try again.');
            setStatus('error');
        }
    };
    
    const handleMicClick = () => {
        if (status === 'listening') {
            stopConversation();
        } else {
            startConversation();
        }
    };

    const handleCopy = (text: string, id: string) => {
        navigator.clipboard.writeText(text);
        setCopiedId(id);
        setTimeout(() => setCopiedId(null), 2000);
    };

    const downloadTranscript = () => {
        if (chatHistory.length === 0) return;
        const formattedTranscript = chatHistory.map(msg => {
            const speaker = msg.speaker === 'user' ? 'You' : 'AI Co-Founder';
            return `[${msg.timestamp}] ${speaker}:\n${msg.text}\n`;
        }).join('\n----------------------------------------\n');
        const blob = new Blob([formattedTranscript], { type: 'text/plain;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.setAttribute('download', 'coflow-chat-transcript.txt');
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-lg flex items-center justify-center z-50 animate-fade-in-up" style={{ animationDuration: '0.3s' }}>
            <div className="bg-[#121212]/80 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl w-full max-w-2xl h-[85vh] max-h-[700px] flex flex-col p-4">
                <header className="flex items-center justify-between pb-3 border-b border-white/10 flex-shrink-0">
                    <h2 className="text-xl font-bold text-white">AI Co-Founder Chat</h2>
                    <div className="flex items-center gap-2">
                         <button onClick={downloadTranscript} className="text-gray-400 hover:text-white disabled:opacity-50 transition-colors" disabled={chatHistory.length === 0} aria-label="Download chat transcript">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
                        </button>
                        <button onClick={onClose} className="text-gray-400 hover:text-white transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </div>
                </header>

                <main className="flex-1 overflow-y-auto p-4 custom-scroll space-y-6">
                    {chatHistory.map((msg) => (
                        <div key={msg.id} className={`flex flex-col ${msg.speaker === 'user' ? 'items-end' : 'items-start'}`}>
                            <div className={`group flex items-end gap-2.5 max-w-[85%] ${msg.speaker === 'user' ? 'flex-row-reverse' : ''}`}>
                                {msg.speaker === 'model' && <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#00E0A9] to-[#6953F0] flex-shrink-0 self-start shadow-lg shadow-[#6953F0]/20"></div>}
                                <div className={`px-4 py-3 rounded-t-2xl ${msg.speaker === 'user' ? 'bg-[#6953F0] text-white rounded-bl-2xl' : 'bg-gray-800 text-white rounded-br-2xl'}`}>
                                    <p className="leading-relaxed">{msg.text}</p>
                                </div>
                                <button onClick={() => handleCopy(msg.text, msg.id)} aria-label="Copy message" className={`w-8 h-8 flex-shrink-0 flex items-center justify-center rounded-full text-gray-400 opacity-0 group-hover:opacity-100 transition-all hover:bg-gray-700 ${copiedId === msg.id ? '!opacity-100 bg-gray-700' : ''}`}>
                                    {copiedId === msg.id ? (
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-[#6953F0]" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                                    ) : (
                                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                                    )}
                                </button>
                            </div>
                            <p className={`text-xs text-gray-500 mt-1.5 ${msg.speaker === 'user' ? 'mr-10' : 'ml-10'}`}>{msg.timestamp}</p>
                        </div>
                    ))}
                    {isTyping && (
                        <div className="flex items-end gap-2.5 justify-start">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#00E0A9] to-[#6953F0] flex-shrink-0"></div>
                            <div className="px-4 py-3 rounded-t-2xl rounded-br-2xl bg-gray-800">
                                <div className="flex items-center space-x-1.5">
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse [animation-delay:-0.3s]"></div>
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse [animation-delay:-0.15s]"></div>
                                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                                </div>
                            </div>
                        </div>
                    )}
                    <div ref={chatHistoryEndRef} />
                </main>
                
                <footer className="pt-4 border-t border-white/10 flex flex-col items-center flex-shrink-0">
                    <button onClick={handleMicClick} className={`w-20 h-20 rounded-full flex items-center justify-center transition-all duration-300 transform-gpu shadow-lg ${status === 'listening' ? 'bg-red-500 hover:bg-red-600 scale-105 shadow-red-500/30' : 'bg-[#6953F0] hover:scale-105 shadow-[#6953F0]/30'}`} aria-label={status === 'listening' ? 'Stop listening' : 'Start listening'}>
                         <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
                    </button>
                    <div className="h-10 mt-2 text-center text-sm text-[#B9C4D7] flex flex-col justify-center">
                        {status === 'connecting' && <p>Connecting...</p>}
                        {status === 'listening' && <p className="text-[#6953F0]">Listening... Tap to stop.</p>}
                        {status === 'idle' && (
                            <>
                                <p>Tap the mic to talk</p>
                                <p className="text-xs text-[#B9C4D7]/80 mt-1">Supports English &amp; Hindi</p>
                            </>
                        )}
                        {status === 'error' && <p className="text-red-400">{errorMessage}</p>}
                    </div>
                </footer>
            </div>
        </div>
    );
};

export default ChatModal;