import React from 'react';

interface ResultCardProps {
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
  onDownloadPlan?: () => void;
  onDownloadPitchDeck?: () => void;
}

const ResultCard: React.FC<ResultCardProps> = ({ title, icon, children, onDownloadPlan, onDownloadPitchDeck }) => {
  return (
    <div className="relative bg-[#121212]/80 backdrop-blur-2xl border border-white/10 rounded-2xl p-6 shadow-2xl shadow-black/40 animate-fade-in-up">
      <div className="absolute inset-0 rounded-2xl bg-black/10" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 800 800\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.65\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")', opacity: 0.025 }}></div>
      <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/10"></div>

      <div className="relative z-10">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-6 pb-4 border-b border-white/10">
          <div className="flex items-center mb-4 sm:mb-0">
            <div className="text-[#00E0A9] mr-4">{icon}</div>
            <h2 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400 tracking-wide">{title}</h2>
          </div>
          {(onDownloadPlan || onDownloadPitchDeck) && (
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 w-full sm:w-auto">
              {onDownloadPlan && (
                <button 
                  onClick={onDownloadPlan}
                  className="flex items-center justify-center gap-2 text-sm bg-white/5 border border-white/10 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-300 group hover:bg-white/10 hover:border-[#6953F0]/50 hover:shadow-lg hover:shadow-[#6953F0]/20"
                  aria-label={`Download ${title} as a plan`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  Download Plan
                </button>
              )}
              {onDownloadPitchDeck && (
                <button 
                  onClick={onDownloadPitchDeck}
                  className="flex items-center justify-center gap-2 text-sm bg-[#00E0A9]/10 border border-[#00E0A9]/50 text-[#00E0A9] font-semibold py-2 px-4 rounded-lg transition-all duration-300 group hover:bg-[#00E0A9]/20 hover:border-[#00E0A9] hover:shadow-lg hover:shadow-[#00E0A9]/20"
                  aria-label={`Download ${title} as a pitch deck`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 20H5a2 2 0 01-2-2V6a2 2 0 012-2h10a2 2 0 012 2v1m2 13a2 2 0 01-2-2V7m2 13a2 2 0 002-2V9a2 2 0 00-2-2h-2m-4-3H9M7 16h6M7 8h6v4H7V8z" />
                  </svg>
                  Download Pitch Deck
                </button>
              )}
            </div>
          )}
        </div>
        <div className="text-[#B9C4D7] space-y-4">
          {children}
        </div>
      </div>
    </div>
  );
};

export default ResultCard;
