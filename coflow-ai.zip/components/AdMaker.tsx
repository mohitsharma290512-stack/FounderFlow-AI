import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';

const fileToBase64 = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = (error) => reject(error);
  });

const progressMessages = [
    'Scripting your ad...',
    'Casting the digital actors...',
    'Setting up the virtual cameras...',
    'Rendering the final cut...',
    'Adding the finishing touches...'
];

const AdMaker: React.FC = () => {
    const [image, setImage] = useState<{ file: File, preview: string } | null>(null);
    const [prompt, setPrompt] = useState('');
    const [aspectRatio, setAspectRatio] = useState<'16:9' | '9:16'>('16:9');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');
    const [videoUrl, setVideoUrl] = useState('');
    const [progressMessage, setProgressMessage] = useState('');
    const [apiKeySelected, setApiKeySelected] = useState(false);

    useEffect(() => {
        const checkKey = async () => {
            if (await window.aistudio.hasSelectedApiKey()) {
                setApiKeySelected(true);
            }
        };
        checkKey();
    }, []);

    const handleSelectKey = async () => {
        await window.aistudio.openSelectKey();
        setApiKeySelected(true); // Assume success to re-render UI
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setImage({ file, preview: URL.createObjectURL(file) });
        }
    };
    
    const handleGenerate = async () => {
        if (!image || !prompt) {
            setError('Please upload an image and provide a prompt.');
            return;
        }
        setIsLoading(true);
        setError('');
        setVideoUrl('');
        setProgressMessage('Warming up the studio lights...');

        try {
            const base64Image = await fileToBase64(image.file);
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

            let operation = await ai.models.generateVideos({
                model: 'veo-3.1-fast-generate-preview',
                prompt: prompt,
                image: { imageBytes: base64Image, mimeType: image.file.type },
                config: { numberOfVideos: 1, resolution: '720p', aspectRatio: aspectRatio }
            });

            let messageIndex = 0;
            const progressInterval = setInterval(() => {
                setProgressMessage(progressMessages[messageIndex % progressMessages.length]);
                messageIndex++;
            }, 5000);

            while (!operation.done) {
                await new Promise(resolve => setTimeout(resolve, 10000));
                operation = await ai.operations.getVideosOperation({ operation: operation });
            }
            
            clearInterval(progressInterval);
            
            if (operation.error) {
                // FIX: Add a type check to ensure 'operation.error.message' is a string before calling '.includes()' to prevent runtime errors on unknown types.
                if (typeof operation.error.message === 'string' && operation.error.message.includes('Requested entity was not found')) {
                    setError('Your API Key is invalid. Please select a valid key to continue.');
                    setApiKeySelected(false);
                    setIsLoading(false);
                    return;
                }
                // FIX: Cast 'operation.error.message' to a string to safely create an Error object, satisfying TypeScript's type requirements.
                throw new Error(String(operation.error.message));
            }

            const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
            if (!downloadLink) throw new Error('Video generation failed to produce a link.');

            setProgressMessage('Downloading your ad...');
            const videoResponse = await fetch(`${downloadLink}&key=${process.env.API_KEY!}`);
            if (!videoResponse.ok) throw new Error('Failed to download the generated video.');
            
            const videoBlob = await videoResponse.blob();
            const url = URL.createObjectURL(videoBlob);
            setVideoUrl(url);

        } catch (e: any) {
            setError(e.message || 'An unexpected error occurred.');
            if (e.message.includes('Requested entity was not found')) {
                setError('Your API Key is invalid. Please select a valid key to continue.');
                setApiKeySelected(false);
            }
        } finally {
            setIsLoading(false);
            setProgressMessage('');
        }
    };

    const handleDownload = () => {
        const a = document.createElement('a');
        a.href = videoUrl;
        a.download = 'coflow-ad.mp4';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    };

    const renderContent = () => {
        if (!apiKeySelected) {
            return (
                <div className="text-center">
                    <h3 className="text-xl font-semibold text-white mb-2">API Key Required for Video Generation</h3>
                    <p className="text-[#B9C4D7] mb-4">
                        This feature uses advanced video generation models. Please select your API key to proceed.
                    </p>
                    <button onClick={handleSelectKey} className="bg-[#6953F0] text-white font-bold py-2 px-6 rounded-lg hover:opacity-90 transition-opacity">
                        Select API Key
                    </button>
                    <p className="text-xs text-[#B9C4D7] mt-3">
                        For more information, see the <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="underline hover:text-[#6953F0]">billing documentation</a>.
                    </p>
                </div>
            );
        }

        if (isLoading) {
            return (
                <div className="flex flex-col items-center justify-center text-center">
                     <svg className="animate-spin h-10 w-10 text-[#6953F0] mb-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <p className="text-lg text-[#00E0A9]">{progressMessage}</p>
                    <p className="text-sm text-[#B9C4D7] mt-2">Video generation can take a few minutes. Please be patient.</p>
                </div>
            );
        }

        if (videoUrl) {
            return (
                <div className="text-center">
                    <h3 className="text-2xl font-bold text-white mb-4">Your Ad is Ready!</h3>
                    <video src={videoUrl} controls className="w-full rounded-lg mb-4 border border-white/10" />
                    <button onClick={handleDownload} className="w-full bg-[#6953F0] text-white font-bold py-3 px-4 rounded-lg hover:opacity-90 transition-opacity">
                        Download Ad
                    </button>
                </div>
            );
        }

        return (
             <div>
                <div className="mb-4">
                    <label className="block text-[#00E0A9] font-semibold mb-2">1. Upload Product Image</label>
                    <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-white/20 border-dashed rounded-lg bg-black/20">
                        <div className="space-y-1 text-center">
                            {image ? (
                                <img src={image.preview} alt="Preview" className="mx-auto h-24 w-auto rounded-md"/>
                            ) : (
                                <svg className="mx-auto h-12 w-12 text-[#B9C4D7]" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                                    <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                                </svg>
                            )}
                            <div className="flex text-sm text-[#B9C4D7]">
                                <label htmlFor="file-upload" className="relative cursor-pointer bg-transparent rounded-md font-medium text-[#6953F0] hover:text-[#00E0A9] focus-within:outline-none">
                                    <span>Upload a file</span>
                                    <input id="file-upload" name="file-upload" type="file" className="sr-only" accept="image/*" onChange={handleFileChange} />
                                </label>
                                <p className="pl-1">or drag and drop</p>
                            </div>
                            <p className="text-xs text-[#B9C4D7]">PNG, JPG, GIF up to 10MB</p>
                        </div>
                    </div>
                </div>
                <div className="mb-4">
                     <label htmlFor="prompt-input" className="block text-[#00E0A9] font-semibold mb-2">2. Describe Your Ad</label>
                     <textarea id="prompt-input" value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="e.g., An epic cinematic shot of this product on a mountain top at sunrise" className="w-full bg-black/20 border-2 border-white/10 rounded-lg p-3 text-white focus:outline-none focus:ring-2 focus:ring-[#6953F0] transition-all h-24"/>
                </div>
                 <div className="mb-6">
                    <label className="block text-[#00E0A9] font-semibold mb-2">3. Choose Aspect Ratio</label>
                    <div className="flex space-x-4">
                        <button onClick={() => setAspectRatio('16:9')} className={`flex-1 p-3 rounded-md border-2 transition-colors ${aspectRatio === '16:9' ? 'bg-[#6953F0]/20 border-[#6953F0]' : 'border-white/20 hover:border-[#6953F0]/50'}`}>Landscape (16:9)</button>
                        <button onClick={() => setAspectRatio('9:16')} className={`flex-1 p-3 rounded-md border-2 transition-colors ${aspectRatio === '9:16' ? 'bg-[#6953F0]/20 border-[#6953F0]' : 'border-white/20 hover:border-[#6953F0]/50'}`}>Portrait (9:16)</button>
                    </div>
                </div>
                <button onClick={handleGenerate} disabled={!image || !prompt} className="w-full bg-[#6953F0] text-white font-bold py-3 px-4 rounded-lg hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-all">
                    Generate Ad
                </button>
            </div>
        );
    };

    return (
        <div className="w-full bg-gray-900/30 backdrop-blur-xl border border-white/10 rounded-2xl p-6 shadow-2xl shadow-black/40 animate-fade-in-up">
            {error && <div className="mb-4 text-center text-red-400 bg-red-900/50 p-3 rounded-md">{error}</div>}
            {renderContent()}
        </div>
    );
};

export default AdMaker;