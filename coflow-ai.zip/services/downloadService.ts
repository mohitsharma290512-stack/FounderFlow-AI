// Since jsPDF is loaded from a CDN, we need to declare it to TypeScript
declare const jspdf: any;

import { CoFlowPlan } from '../types';

// A helper class to write content to a PDF, managing layout and page breaks.
class PdfWriter {
  private doc: any;
  private y: number;
  private pageMargin = 15;
  private pageHeight: number;
  private lineSpacing = 7;
  private contentWidth: number;

  constructor() {
    this.doc = new jspdf.jsPDF();
    this.y = this.pageMargin;
    this.pageHeight = this.doc.internal.pageSize.getHeight();
    this.contentWidth = this.doc.internal.pageSize.getWidth() - this.pageMargin * 2;
  }

  private checkPageBreak(requiredHeight = 0) {
    if (this.y + requiredHeight > this.pageHeight - this.pageMargin) {
      this.doc.addPage();
      this.y = this.pageMargin;
    }
  }

  addTitle(text: string, size = 18) {
    this.doc.setFont('helvetica', 'bold');
    this.doc.setFontSize(size);
    this.checkPageBreak(12);
    this.doc.text(text, this.doc.internal.pageSize.getWidth() / 2, this.y, { align: 'center' });
    this.y += this.lineSpacing * 2;
  }
  
  addSubtitle(text: string) {
    this.doc.setFont('helvetica', 'italic');
    this.doc.setFontSize(12);
    this.doc.setTextColor(100);
    this.checkPageBreak(10);
    this.doc.text(text, this.doc.internal.pageSize.getWidth() / 2, this.y, { align: 'center' });
    this.y += this.lineSpacing * 2;
    this.doc.setTextColor(0);
  }

  addHeading(text: string) {
    this.doc.setFont('helvetica', 'bold');
    this.doc.setFontSize(14);
    this.checkPageBreak(10);
    this.doc.text(text, this.pageMargin, this.y);
    this.y += this.lineSpacing * 1.5;
  }

  addBody(text: string, indent = 0) {
    this.doc.setFont('helvetica', 'normal');
    this.doc.setFontSize(11);
    const splitText = this.doc.splitTextToSize(text, this.contentWidth - indent);
    const textHeight = this.doc.getTextDimensions(splitText).h;
    this.checkPageBreak(textHeight);
    this.doc.text(splitText, this.pageMargin + indent, this.y);
    this.y += textHeight + this.lineSpacing / 2;
  }
  
  // FIX: Add a public method to add vertical spacing, preventing direct access to the private 'y' property.
  addSpacing(space: number) {
    this.checkPageBreak(space);
    this.y += space;
  }

  addSeparator() {
      this.y += this.lineSpacing / 2;
      this.checkPageBreak(5);
      this.doc.setDrawColor(200, 200, 200);
      this.doc.line(this.pageMargin, this.y, this.doc.internal.pageSize.getWidth() - this.pageMargin, this.y);
      this.y += this.lineSpacing;
  }

  save(filename: string) {
    this.doc.save(filename);
  }
}

const formatCoFlowPlan = (writer: PdfWriter, data: CoFlowPlan) => {
    writer.addTitle(`🚀 ${data.startupName}`);

    writer.addHeading('🎯 Problem Summary');
    writer.addBody(data.problemSummary);
    writer.addSeparator();

    writer.addHeading('✅ Proposed Solution');
    writer.addBody(data.proposedSolution);
    writer.addSeparator();

    writer.addHeading('👥 Target Audience');
    writer.addBody(data.targetAudience);
    writer.addSeparator();

    writer.addHeading('🧠 Insight');
    writer.addBody(data.insight);
    writer.addSeparator();

    writer.addHeading('🏗️ MVP Plan');
    writer.addBody('Phase 1 (1 Week): Core Validation');
    data.mvpPlan.phase1.forEach(item => writer.addBody(`• ${item}`, 5));
    writer.addSpacing(5);
    writer.addBody('Phase 2 (2–4 Weeks): Retention Features');
    data.mvpPlan.phase2.forEach(item => writer.addBody(`• ${item}`, 5));
    writer.addSpacing(5);
    writer.addBody('Phase 3 (Scale): Growth & Defensibility');
    data.mvpPlan.phase3.forEach(item => writer.addBody(`• ${item}`, 5));
    writer.addSpacing(5);
    writer.addSeparator();
    
    writer.addHeading('🛠️ Recommended Tech Stack');
    data.techStack.forEach(item => writer.addBody(`• ${item}`, 5));
    writer.addSpacing(5);
    writer.addSeparator();

    writer.addHeading('📈 Go-to-Market Strategy');
    data.goToMarketStrategy.forEach(item => writer.addBody(`• ${item}`, 5));
    writer.addSpacing(5);
    writer.addSeparator();
    
    writer.addHeading('💰 Monetization Strategy');
    writer.addBody(data.monetizationStrategy);
    writer.addSeparator();

    writer.addHeading('🎨 Branding & UI Theme');
    writer.addBody(data.brandingTheme);
};


export const downloadResultAsPdf = (data: CoFlowPlan) => {
    const writer = new PdfWriter();
    const filename = `coflow-blueprint-${data.startupName.toLowerCase().replace(/\s/g, '-')}.pdf`;
    
    formatCoFlowPlan(writer, data);
    
    writer.save(filename);
};

export const downloadPitchDeckAsPdf = (data: CoFlowPlan) => {
    const doc = new jspdf.jsPDF({ orientation: 'landscape' });
    const pageMargin = 15;
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const contentWidth = pageWidth - pageMargin * 2;

    const addSlide = (title: string, content: string | string[]) => {
        doc.addPage();
        // Background
        doc.setFillColor('#0B0B0E');
        doc.rect(0, 0, pageWidth, pageHeight, 'F');
        
        // Slide Title
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(28);
        doc.setTextColor('#00E0A9');
        doc.text(title, pageMargin, pageMargin + 15);

        // Underline
        doc.setDrawColor('#6953F0');
        doc.setLineWidth(1);
        doc.line(pageMargin, pageMargin + 20, pageMargin + 60, pageMargin + 20);

        // Content
        doc.setFont('helvetica', 'normal');
        doc.setFontSize(14);
        doc.setTextColor('#FFFFFF');
        
        const contentY = pageMargin + 40;

        if (Array.isArray(content)) {
            let y = contentY;
            content.forEach(item => {
                const splitText = doc.splitTextToSize(`• ${item}`, contentWidth - 5);
                if (y + doc.getTextDimensions(splitText).h > pageHeight - pageMargin) {
                    doc.addPage();
                    // Re-add background and title on new page
                    doc.setFillColor('#0B0B0E');
                    doc.rect(0, 0, pageWidth, pageHeight, 'F');
                    doc.setFont('helvetica', 'bold');
                    doc.setFontSize(28);
                    doc.setTextColor('#00E0A9');
                    doc.text(title, pageMargin, pageMargin + 15);
                    doc.setDrawColor('#6953F0');
                    doc.setLineWidth(1);
                    doc.line(pageMargin, pageMargin + 20, pageMargin + 60, pageMargin + 20);
                    doc.setFont('helvetica', 'normal');
                    doc.setFontSize(14);
                    doc.setTextColor('#FFFFFF');
                    y = contentY;
                }
                doc.text(splitText, pageMargin + 5, y);
                y += doc.getTextDimensions(splitText).h + 4;
            });
        } else {
            const splitText = doc.splitTextToSize(content, contentWidth);
            doc.text(splitText, pageMargin, contentY);
        }
    };

    // --- Slide Generation ---

    // 1. Title Slide
    doc.setFillColor('#0B0B0E');
    doc.rect(0, 0, pageWidth, pageHeight, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(48);
    doc.setTextColor('#FFFFFF');
    doc.text(data.startupName, pageWidth / 2, pageHeight / 2 - 10, { align: 'center' });
    doc.setFontSize(20);
    doc.setTextColor('#B9C4D7');
    doc.text('An Investment Opportunity', pageWidth / 2, pageHeight / 2 + 10, { align: 'center' });
    
    // Remove the default first page
    doc.deletePage(1);

    // 2. Problem
    addSlide('The Problem', data.problemSummary);

    // 3. Solution
    addSlide('Our Solution', data.proposedSolution);
    
    // 4. Target Audience
    addSlide('Target Audience', data.targetAudience);

    // 5. The Insight
    addSlide('The Insight (Why Now?)', data.insight);
    
    // 6. MVP Roadmap
    addSlide('MVP Roadmap', [
        "Phase 1: Core Validation",
        ...data.mvpPlan.phase1.map(s => `  - ${s}`),
        "Phase 2: Retention Features",
        ...data.mvpPlan.phase2.map(s => `  - ${s}`),
        "Phase 3: Growth & Scale",
        ...data.mvpPlan.phase3.map(s => `  - ${s}`),
    ]);
    
    // 7. Tech Stack
    addSlide('Recommended Tech Stack', data.techStack);

    // 8. Go-To-Market
    addSlide('Go-To-Market Strategy', data.goToMarketStrategy);
    
    // 9. Business Model
    addSlide('Business Model', data.monetizationStrategy);
    
    // 10. Team
    addSlide('Our Team', [
        "Founder/CEO - [Your Name Here]",
        "Co-founder/CTO - [Co-founder Name]",
        "Advisor - [Advisor Name]"
    ]);

    // 11. Call to Action
    addSlide('Join Us', [
        "Thank you for your time.",
        "Contact: [Your Name] at [your-email@example.com]"
    ]);
    
    const filename = `coflow-pitch-deck-${data.startupName.toLowerCase().replace(/\s/g, '-')}.pdf`;
    doc.save(filename);
};