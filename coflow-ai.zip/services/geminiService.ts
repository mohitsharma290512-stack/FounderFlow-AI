import { GoogleGenAI, Type } from "@google/genai";
import { CoFlowPlan } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const getCoFlowPromptAndSchema = (idea: string) => {
    const prompt = `
        You are CoFlow AI, an expert AI Co-Founder. Your goal is to help founders turn startup ideas into launch-ready execution plans with clarity, structure, and confidence.
        A user has provided the following startup concept: "${idea}"
        
        If the user gives any idea, problem, or concept — no matter how short — automatically generate a full Startup Blueprint.
        
        Always output using this exact structure and return it as a JSON object:
        - 🚀 Startup Name:
        - 🎯 Problem Summary: (A clear, concise summary of the problem)
        - ✅ Proposed Solution: (A clear, concise summary of the solution)
        - 👥 Target Audience:
        - 🧠 Insight (Why Now / Why it Matters):
        - 🏗️ MVP Plan (Phase 1 → Phase 2 → Phase 3): (An object with three keys: 'phase1', 'phase2', 'phase3'. Each key should be an array of strings representing action steps.)
          - Phase 1 (1 Week): Core minimum feature to validate value.
          - Phase 2 (2–4 Weeks): Features that increase retention.
          - Phase 3 (Scale): Features for growth and defensibility.
        - 🛠️ Recommended Tech Stack: (An array of strings. List tools that are easy to build fast — no overengineering.)
        - 📈 Go-To-Market Strategy (Launch Plan): (An array of strings. Who to reach, where to find them, how to get first 100 users.)
        - 💰 Monetization Strategy: (A single string explaining the simplest and fastest monetizable model.)
        - 🎨 Branding & UI Theme Recommendation: (A single string. Use Neon Purple + Dark UI + Glassmorphism style as a base.)

        Always make the blueprint concise, simple, and founder-level strategic. Never produce long essays; use bullet points for arrays and clarity.
    `;
    
    const schema = {
        type: Type.OBJECT,
        properties: {
            startupName: { type: Type.STRING },
            problemSummary: { type: Type.STRING },
            proposedSolution: { type: Type.STRING },
            targetAudience: { type: Type.STRING },
            insight: { type: Type.STRING },
            mvpPlan: {
                type: Type.OBJECT,
                properties: {
                    phase1: { type: Type.ARRAY, items: { type: Type.STRING } },
                    phase2: { type: Type.ARRAY, items: { type: Type.STRING } },
                    phase3: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
                required: ["phase1", "phase2", "phase3"]
            },
            techStack: { type: Type.ARRAY, items: { type: Type.STRING } },
            goToMarketStrategy: { type: Type.ARRAY, items: { type: Type.STRING } },
            monetizationStrategy: { type: Type.STRING },
            brandingTheme: { type: Type.STRING },
        },
        required: ["startupName", "problemSummary", "proposedSolution", "targetAudience", "insight", "mvpPlan", "techStack", "goToMarketStrategy", "monetizationStrategy", "brandingTheme"],
    };

    return { prompt, schema };
};


export const generateCoFlowPlan = async (
  idea: string,
): Promise<CoFlowPlan> => {
  const { prompt, schema } = getCoFlowPromptAndSchema(idea);
  
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: schema,
      },
    });

    const jsonString = response.text.trim();
    const sanitizedJsonString = jsonString.replace(/^```json\s*|```\s*$/g, '');
    const parsedJson = JSON.parse(sanitizedJsonString);
    
    return parsedJson as CoFlowPlan;
  } catch (error) {
    console.error("Error generating content with Gemini:", error);
    throw new Error("Failed to generate content. Please check your API key and try again.");
  }
};