import React, { useState, useCallback, useMemo, useRef } from 'react';
import { CoFlowPlan } from './types';
import { generateCoFlowPlan } from './services/geminiService';
import { downloadResultAsPdf, downloadPitchDeckAsPdf } from './services/downloadService';
import ResultCard from './components/ResultCard';
import LoadingSpinner from './components/LoadingSpinner';
import { CoFlowPlanDisplay } from './components/ResultDisplays';
import AvatarChatModal from './components/AvatarChatModal';

const App: React.FC = () => {
  const [idea, setIdea] = useState<string>('');

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<CoFlowPlan | null>(null);
  const [isChatOpen, setIsChatOpen] = useState<boolean>(false);
  
  const mainContentRef = useRef<HTMLDivElement>(null);

  const handleStartBuilding = () => {
    mainContentRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const isFormComplete = useMemo(() => {
    return idea.trim() !== '';
  }, [idea]);

  const handleSubmit = useCallback(async () => {
    if (!isFormComplete) {
      setError('Please describe your idea to generate your blueprint.');
      return;
    }
    setError(null);
    setIsLoading(true);
    setResult(null);

    try {
      const generatedContent = await generateCoFlowPlan(idea);
      setResult(generatedContent);
    } catch (e) {
      const err = e as Error;
      setError(err.message || 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [idea, isFormComplete]);

  const renderResult = () => {
    if (!result) return null;

    const handleDownloadPlan = () => {
        if (result) {
          downloadResultAsPdf(result);
        }
    };
    
    const handleDownloadPitchDeck = () => {
        if (result) {
            downloadPitchDeckAsPdf(result);
        }
    };

    const resultIcon = (
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
        <defs>
          <linearGradient id="resGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style={{stopColor: '#00E0A9', stopOpacity: 1}} />
            <stop offset="100%" style={{stopColor: '#6953F0', stopOpacity: 1}} />
          </linearGradient>
        </defs>
        <path d="M2 17l10 5 10-5" stroke="url(#resGrad)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M2 12l10 5 10-5" stroke="url(#resGrad)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M12 2L2 7l10 5 10-5-10-5z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" opacity="0.6"/>
      </svg>
    );

    return (
      <div className="mt-8 w-full">
        <ResultCard 
            title="Your Startup Blueprint" 
            icon={resultIcon}
            onDownloadPlan={handleDownloadPlan}
            onDownloadPitchDeck={handleDownloadPitchDeck}
        >
          <CoFlowPlanDisplay data={result} />
        </ResultCard>
      </div>
    );
  };
  
  return (
    <div className="min-h-screen text-white flex flex-col items-center p-4 sm:p-6 md:p-8 custom-scroll">
      <div className="w-full max-w-4xl mx-auto">
        <header className="text-center my-16 md:my-24 animate-fade-in-up">
          <h1 className="text-5xl md:text-7xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-[#ffffff] to-[#00E0A9] drop-shadow-[0_0_35px_rgba(0,224,169,0.4)] tracking-tight">
            Your AI Co-Founder to Plan, Build, and Launch Your Startup.
          </h1>
          <p className="mt-6 text-lg md:text-xl text-[#B9C4D7] tracking-wider max-w-3xl mx-auto">
            Describe your idea. CoFlow AI transforms it into a business model, feature plan, roadmap, and launch strategy — instantly.
          </p>
          <div className="mt-8">
             <button
              onClick={handleStartBuilding}
              className="group relative inline-flex items-center justify-center py-3 px-12 bg-[#6953F0] text-white font-bold text-lg rounded-lg shadow-lg shadow-[#6953F0]/30 hover:shadow-xl hover:shadow-[#6953F0]/40 transition-all duration-300 transform hover:-translate-y-1 overflow-hidden"
            >
              <span className="absolute h-0 w-0 rounded-full bg-[#00E0A9]/50 transition-all duration-500 ease-out group-hover:h-56 group-hover:w-56"></span>
              <span className="relative">Start Building →</span>
            </button>
          </div>
        </header>

        <section className="my-16 md:my-24">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
                <div className="bg-[#121212]/80 backdrop-blur-xl border border-white/10 p-6 rounded-2xl animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
                    <h3 className="text-2xl font-bold text-[#00E0A9] mb-3">📄 Startup Blueprint Engine</h3>
                    <p className="text-[#B9C4D7] leading-relaxed">
                        Turn any idea into a clear startup plan. Get value proposition, customer personas, pricing, and problem-solution fit — instantly.
                    </p>
                </div>
                 <div className="bg-[#121212]/80 backdrop-blur-xl border border-white/10 p-6 rounded-2xl animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
                    <h3 className="text-2xl font-bold text-[#00E0A9] mb-3">🗓️ 4-Week MVP Roadmap</h3>
                    <p className="text-[#B9C4D7] leading-relaxed">
                        No more confusion. CoFlow generates a step-by-step build plan. Week-by-week milestones. Clear tasks. Fast execution.
                    </p>
                </div>
                 <div className="bg-[#121212]/80 backdrop-blur-xl border border-white/10 p-6 rounded-2xl animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
                    <h3 className="text-2xl font-bold text-[#00E0A9] mb-3">🎤 Auto Pitch Deck Creator</h3>
                    <p className="text-[#B9C4D7] leading-relaxed">
                        One click → ready-to-present 8-slide founder pitch. Perfect for hackathons, demos, and investors.
                    </p>
                </div>
            </div>
        </section>

        <main ref={mainContentRef} className="w-full pt-12">
          <div className="relative bg-[#121212]/80 backdrop-blur-2xl border border-white/10 rounded-2xl p-6 shadow-2xl shadow-black/40 animate-fade-in-up" style={{ animationDelay: '0.2s' }}>
            <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-white/10"></div>
            <div className="absolute inset-0 rounded-2xl bg-black/10" style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 800 800\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noiseFilter\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.65\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noiseFilter)\'/%3E%3C/svg%3E")', opacity: 0.025 }}></div>
            <div className="relative z-10 space-y-6">
                <div>
                    <label htmlFor="idea-input" className="block text-white font-semibold text-lg mb-2">Describe your idea in one sentence</label>
                    <textarea id="idea-input" value={idea} onChange={(e) => setIdea(e.target.value)} placeholder="e.g., An app that helps students study faster..." className="w-full bg-black/20 border-2 border-white/10 rounded-lg p-3 text-white/90 placeholder:text-[#B9C4D7]/50 focus:outline-none focus:ring-2 focus:ring-[#6953F0] focus:border-[#6953F0] transition-all duration-300 h-24 text-md" />
                </div>
            </div>
          </div>

          <div className="mt-8 text-center animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
            <button
              onClick={handleSubmit}
              disabled={isLoading || !isFormComplete}
              className="group relative inline-flex items-center justify-center py-3 px-12 bg-[#6953F0] text-white font-bold text-lg rounded-lg shadow-lg shadow-[#6953F0]/30 hover:shadow-xl hover:shadow-[#6953F0]/40 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:-translate-y-1 overflow-hidden"
            >
              <span className="absolute h-0 w-0 rounded-full bg-[#00E0A9]/50 transition-all duration-500 ease-out group-hover:h-56 group-hover:w-56"></span>
              <span className="relative">Generate Startup Blueprint 🚀</span>
            </button>
          </div>
          
          {error && <div className="mt-6 text-center text-red-400 bg-red-900/50 p-3 rounded-lg border border-red-500/50 animate-fade-in-up">{error}</div>}

          <div className="mt-8 w-full flex justify-center">
            {isLoading && <LoadingSpinner />}
          </div>

          {result && renderResult()}
        </main>

        <footer className="text-center text-[#B9C4D7]/80 text-sm py-8 mt-12">
          <p>&copy; {new Date().getFullYear()} CoFlow AI. All rights reserved.</p>
        </footer>
      </div>
      
      <button
        onClick={() => setIsChatOpen(true)}
        className="fixed bottom-6 right-6 sm:bottom-8 sm:right-8 bg-gradient-to-r from-[#00E0A9] to-[#6953F0] text-white p-4 rounded-full shadow-2xl shadow-[#6953F0]/30 hover:scale-110 transform transition-transform duration-200 ease-in-out z-50 animate-subtle-float"
        aria-label="Talk to AI Co-Founder"
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
        </svg>
      </button>

      {isChatOpen && <AvatarChatModal onClose={() => setIsChatOpen(false)} />}
    </div>
  );
};

export default App;