
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-gray-900/50 backdrop-blur-sm border-b border-gray-800 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-500">
          Startup Spark ✨
        </h1>
        <p className="text-sm text-gray-400">Your AI Business Co-Pilot</p>
      </div>
    </header>
  );
};

export default Header;
