
import React from 'react';

export type Page =
  | 'home'
  | 'blueprint'
  | 'pitch_deck'
  | 'task_planner'
  | 'branding'
  | 'market_research'
  | 'prototype'
  | 'founder_chat'
  | 'historical_insights';

export interface PageProps {
  navigate: (page: Page) => void;
  idea: string;
  setIdea: React.Dispatch<React.SetStateAction<string>>;
}

export interface Blueprint {
  problemStatement: string;
  targetUsers: string[];
  marketFit: string;
  monetizationStrategy: string;
  launchRoadmap: { phase: string; details: string }[];
}

export interface PitchDeck {
  deckOutline: { slide: number; title: string; content: string }[];
  demoScript: string;
  elevatorPitches: {
    thirtySecond: string;
    sixtySecond: string;
    threeMinute: string;
  };
}

export interface Task {
  task: string;
  milestone: string;
  priority: 'High' | 'Medium' | 'Low';
  deadline: string;
}

export interface Branding {
  names: string[];
  taglines: string[];
  logoPrompt: string;
  colorPalette: { hex: string; name: string; vibe: string }[];
}

export interface Competitor {
  name: string;
  pricing: string;
  strengths: string[];
  weaknesses: string[];
  strategyToBeat: string;
}

export interface MarketResearchData {
    competitors: Competitor[];
    marketSummary: string;
}

export interface HistoricalCaseStudy {
  companyName: string;
  outcome: string;
  keyLesson: string;
}

export interface HistoricalInsightsData {
  keySuccessFactors: string[];
  commonPitfalls: string[];
  caseStudies: HistoricalCaseStudy[];
  strategicRecommendations: string;
}

export interface Prototype {
  figmaInstructions: string;
  asciiWireframe: string;
}
