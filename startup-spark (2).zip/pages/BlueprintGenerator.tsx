
import React, { useState, useCallback } from 'react';
import { PageProps, Blueprint } from '../types';
import { generateBlueprint } from '../services/geminiService';
import { Spinner, BackIcon } from '../components/icons';

const BlueprintGenerator: React.FC<PageProps> = ({ navigate, idea, setIdea }) => {
  const [result, setResult] = useState<Blueprint | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!idea.trim()) {
      setError('Please enter a startup idea.');
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const blueprint = await generateBlueprint(idea);
      setResult(blueprint);
    } catch (e) {
      setError('Failed to generate blueprint. Please try again.');
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [idea]);

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
      <button onClick={() => navigate('home')} className="flex items-center text-indigo-400 hover:text-indigo-300 mb-6 font-semibold">
        <BackIcon />
        Back to Tools
      </button>

      <h2 className="text-3xl font-bold mb-2">Startup Blueprint Generator</h2>
      <p className="text-gray-400 mb-6">Enter your startup idea, and let the AI build a foundational business plan for you.</p>

      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 mb-8">
        <textarea
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          placeholder="e.g., A mobile app that uses AI to create personalized workout plans"
          className="w-full h-24 p-3 bg-gray-800 border border-gray-700 rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-colors"
          disabled={loading}
        />
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="mt-4 w-full flex justify-center items-center px-6 py-3 bg-indigo-600 text-white font-bold rounded-md hover:bg-indigo-700 disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors"
        >
          {loading ? <><Spinner className="mr-2" /> Generating...</> : 'Generate Blueprint'}
        </button>
        {error && <p className="text-red-400 mt-4 text-center">{error}</p>}
      </div>
      
      {result && (
        <div className="space-y-6 animate-fade-in bg-gray-900/50 border border-gray-800 rounded-lg p-6">
          <Section title="Problem Statement" content={result.problemStatement} />
          <Section title="Target Users">
             <ul className="list-disc list-inside space-y-1 text-gray-300">{result.targetUsers.map((user, i) => <li key={i}>{user}</li>)}</ul>
          </Section>
          <Section title="Market Fit" content={result.marketFit} />
          <Section title="Monetization Strategy" content={result.monetizationStrategy} />
          <Section title="Launch Roadmap">
            <div className="space-y-4">
            {result.launchRoadmap.map((item, i) => (
                <div key={i} className="p-4 bg-gray-800/50 border-l-4 border-indigo-500 rounded-r-md">
                    <h4 className="font-semibold text-indigo-300">{item.phase}</h4>
                    <p className="text-gray-300">{item.details}</p>
                </div>
            ))}
            </div>
          </Section>
        </div>
      )}
    </div>
  );
};

const Section: React.FC<{ title: string; content?: string; children?: React.ReactNode }> = ({ title, content, children }) => (
  <div>
    <h3 className="text-xl font-semibold text-indigo-400 mb-2">{title}</h3>
    {content && <p className="text-gray-300 whitespace-pre-wrap">{content}</p>}
    {children}
  </div>
);

export default BlueprintGenerator;
