
import React, { useState, useCallback } from 'react';
import { PageProps, PitchDeck } from '../types';
import { generatePitchDeck } from '../services/geminiService';
import { Spinner, BackIcon } from '../components/icons';

const PitchDeckMaker: React.FC<PageProps> = ({ navigate, idea, setIdea }) => {
  const [result, setResult] = useState<PitchDeck | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!idea.trim()) {
      setError('Please enter a startup idea.');
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const pitchDeck = await generatePitchDeck(idea);
      setResult(pitchDeck);
    } catch (e) {
      setError('Failed to generate pitch deck. Please try again.');
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [idea]);

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
       <button onClick={() => navigate('home')} className="flex items-center text-indigo-400 hover:text-indigo-300 mb-6 font-semibold">
        <BackIcon />
        Back to Tools
      </button>

      <h2 className="text-3xl font-bold mb-2">Pitch Deck & Demo Script Maker</h2>
      <p className="text-gray-400 mb-6">Instantly create a professional pitch deck outline, a compelling demo script, and memorable elevator pitches.</p>

      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 mb-8">
        <textarea
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          placeholder="e.g., A subscription box for rare, ethically sourced coffees"
          className="w-full h-24 p-3 bg-gray-800 border border-gray-700 rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-colors"
          disabled={loading}
        />
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="mt-4 w-full flex justify-center items-center px-6 py-3 bg-indigo-600 text-white font-bold rounded-md hover:bg-indigo-700 disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors"
        >
          {loading ? <><Spinner className="mr-2" /> Generating...</> : 'Generate Assets'}
        </button>
        {error && <p className="text-red-400 mt-4 text-center">{error}</p>}
      </div>

      {result && (
        <div className="space-y-8 animate-fade-in">
          <Section title="10-Slide Investor Deck Outline">
            <div className="space-y-4">
              {result.deckOutline.map(slide => (
                <div key={slide.slide} className="p-4 bg-gray-900/50 border border-gray-800 rounded-lg">
                  <h4 className="font-semibold text-indigo-300">Slide {slide.slide}: {slide.title}</h4>
                  <p className="text-gray-300 mt-1">{slide.content}</p>
                </div>
              ))}
            </div>
          </Section>
          <Section title="Demo Video Script" content={result.demoScript} />
          <Section title="Elevator Pitches">
            <div className="space-y-4">
                <Pitch title="30-Second Pitch" content={result.elevatorPitches.thirtySecond} />
                <Pitch title="60-Second Pitch" content={result.elevatorPitches.sixtySecond} />
                <Pitch title="3-Minute Pitch" content={result.elevatorPitches.threeMinute} />
            </div>
          </Section>
        </div>
      )}
    </div>
  );
};

const Section: React.FC<{ title: string; content?: string; children?: React.ReactNode }> = ({ title, content, children }) => (
    <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
        <h3 className="text-xl font-semibold text-indigo-400 mb-4 border-b border-gray-700 pb-2">{title}</h3>
        {content && <p className="text-gray-300 whitespace-pre-wrap">{content}</p>}
        {children}
    </div>
);

const Pitch: React.FC<{title: string; content: string}> = ({title, content}) => (
    <div>
        <h4 className="font-semibold text-indigo-300">{title}</h4>
        <p className="text-gray-300 italic mt-1">"{content}"</p>
    </div>
);


export default PitchDeckMaker;
