
import React, { useState, useCallback } from 'react';
import { PageProps, Task } from '../types';
import { generateTaskPlanner } from '../services/geminiService';
import { Spinner, BackIcon } from '../components/icons';

const priorityColors = {
  High: 'bg-red-500/20 text-red-300 border-red-500/30',
  Medium: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
  Low: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
};

const TaskPlanner: React.FC<PageProps> = ({ navigate, idea, setIdea }) => {
  const [result, setResult] = useState<{ tasks: Task[] } | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!idea.trim()) {
      setError('Please enter a startup idea to generate tasks for.');
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const tasks = await generateTaskPlanner(idea);
      setResult(tasks);
    } catch (e) {
      setError('Failed to generate task plan. Please try again.');
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [idea]);

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
      <button onClick={() => navigate('home')} className="flex items-center text-indigo-400 hover:text-indigo-300 mb-6 font-semibold">
        <BackIcon />
        Back to Tools
      </button>

      <h2 className="text-3xl font-bold mb-2">Task Breakdown + Founder To-Do Planner</h2>
      <p className="text-gray-400 mb-6">Automatically break down your startup goals into daily tasks, milestones, and priorities.</p>

      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 mb-8">
        <textarea
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          placeholder="e.g., Launch a beta version of our SaaS product in 3 months"
          className="w-full h-24 p-3 bg-gray-800 border border-gray-700 rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-colors"
          disabled={loading}
        />
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="mt-4 w-full flex justify-center items-center px-6 py-3 bg-indigo-600 text-white font-bold rounded-md hover:bg-indigo-700 disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors"
        >
          {loading ? <><Spinner className="mr-2" /> Generating Plan...</> : 'Generate Plan'}
        </button>
        {error && <p className="text-red-400 mt-4 text-center">{error}</p>}
      </div>
      
      {result && (
        <div className="animate-fade-in bg-gray-900/50 border border-gray-800 rounded-lg p-6">
          <h3 className="text-xl font-semibold text-indigo-400 mb-4">Your 3-Month Action Plan</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="border-b border-gray-700 text-sm text-gray-400">
                <tr>
                  <th className="p-2">Task</th>
                  <th className="p-2">Milestone</th>
                  <th className="p-2">Priority</th>
                  <th className="p-2">Deadline</th>
                </tr>
              </thead>
              <tbody>
                {result.tasks.map((task, i) => (
                  <tr key={i} className="border-b border-gray-800">
                    <td className="p-3 text-gray-200">{task.task}</td>
                    <td className="p-3 text-gray-400">{task.milestone}</td>
                    <td className="p-3">
                      <span className={`px-2 py-1 text-xs font-semibold rounded-full border ${priorityColors[task.priority]}`}>
                        {task.priority}
                      </span>
                    </td>
                    <td className="p-3 text-gray-400">{task.deadline}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};

export default TaskPlanner;
