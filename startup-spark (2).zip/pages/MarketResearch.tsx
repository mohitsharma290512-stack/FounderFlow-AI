
import React, { useState, useCallback } from 'react';
import { PageProps, MarketResearchData } from '../types';
import { generateMarketResearch } from '../services/geminiService';
import { Spinner, BackIcon } from '../components/icons';

const MarketResearch: React.FC<PageProps> = ({ navigate, idea, setIdea }) => {
  const [result, setResult] = useState<MarketResearchData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!idea.trim()) {
      setError('Please enter a startup idea.');
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const research = await generateMarketResearch(idea);
      setResult(research);
    } catch (e) {
      setError('Failed to generate market research. Please try again.');
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [idea]);

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
       <button onClick={() => navigate('home')} className="flex items-center text-indigo-400 hover:text-indigo-300 mb-6 font-semibold">
        <BackIcon />
        Back to Tools
      </button>

      <h2 className="text-3xl font-bold mb-2">Competitor & Market Research</h2>
      <p className="text-gray-400 mb-6">Gain a competitive edge. AI scans top products, their pricing, strengths, weaknesses, and how you can beat them.</p>

      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 mb-8">
        <textarea
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          placeholder="e.g., A social media platform for book lovers"
          className="w-full h-24 p-3 bg-gray-800 border border-gray-700 rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-colors"
          disabled={loading}
        />
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="mt-4 w-full flex justify-center items-center px-6 py-3 bg-indigo-600 text-white font-bold rounded-md hover:bg-indigo-700 disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors"
        >
          {loading ? <><Spinner className="mr-2" /> Researching...</> : 'Analyze Market'}
        </button>
        {error && <p className="text-red-400 mt-4 text-center">{error}</p>}
      </div>

      {result && (
        <div className="space-y-8 animate-fade-in">
          <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-indigo-400 mb-2">Market Summary</h3>
            <p className="text-gray-300">{result.marketSummary}</p>
          </div>
          <div>
            <h3 className="text-2xl font-bold text-center mb-6">Competitor Analysis</h3>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {result.competitors.map((competitor, i) => (
                <div key={i} className="bg-gray-900/50 border border-gray-800 rounded-lg p-5 flex flex-col">
                  <h4 className="text-lg font-bold text-white">{competitor.name}</h4>
                  <p className="text-sm text-gray-400 mb-4">Pricing: {competitor.pricing}</p>
                  
                  <h5 className="font-semibold text-green-400 mb-1">Strengths</h5>
                  <ul className="list-disc list-inside text-sm text-gray-300 mb-3 space-y-1">
                    {competitor.strengths.map((s, j) => <li key={j}>{s}</li>)}
                  </ul>

                  <h5 className="font-semibold text-red-400 mb-1">Weaknesses</h5>
                  <ul className="list-disc list-inside text-sm text-gray-300 mb-4 space-y-1">
                    {competitor.weaknesses.map((w, j) => <li key={j}>{w}</li>)}
                  </ul>
                  <div className="mt-auto pt-4 border-t border-gray-800">
                     <h5 className="font-semibold text-indigo-300 mb-1">How to Beat Them</h5>
                    <p className="text-sm text-gray-300">{competitor.strategyToBeat}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MarketResearch;
