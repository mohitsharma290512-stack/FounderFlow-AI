
import React, { useState, useCallback } from 'react';
import { PageProps, Branding } from '../types';
import { generateBranding } from '../services/geminiService';
import { Spinner, BackIcon } from '../components/icons';

const BrandingStudio: React.FC<PageProps> = ({ navigate, idea, setIdea }) => {
  const [result, setResult] = useState<Branding | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!idea.trim()) {
      setError('Please enter a startup idea.');
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const branding = await generateBranding(idea);
      setResult(branding);
    } catch (e) {
      setError('Failed to generate branding assets. Please try again.');
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [idea]);

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
       <button onClick={() => navigate('home')} className="flex items-center text-indigo-400 hover:text-indigo-300 mb-6 font-semibold">
        <BackIcon />
        Back to Tools
      </button>

      <h2 className="text-3xl font-bold mb-2">Product Naming + Branding Studio</h2>
      <p className="text-gray-400 mb-6">Go from idea to brand identity in seconds. Generate names, taglines, logo prompts, and a color palette.</p>

      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 mb-8">
        <textarea
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          placeholder="e.g., An educational platform for learning quantum computing"
          className="w-full h-24 p-3 bg-gray-800 border border-gray-700 rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-colors"
          disabled={loading}
        />
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="mt-4 w-full flex justify-center items-center px-6 py-3 bg-indigo-600 text-white font-bold rounded-md hover:bg-indigo-700 disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors"
        >
          {loading ? <><Spinner className="mr-2" /> Generating...</> : 'Generate Brand Identity'}
        </button>
        {error && <p className="text-red-400 mt-4 text-center">{error}</p>}
      </div>

      {result && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-fade-in">
            <Section title="Startup Names" items={result.names} />
            <Section title="Taglines" items={result.taglines} />
            <div className="md:col-span-2">
                <Section title="Logo Prompt">
                    <p className="text-gray-300 font-mono bg-gray-800/50 p-4 rounded-md">{result.logoPrompt}</p>
                </Section>
            </div>
            <div className="md:col-span-2">
                <Section title="Color Palette & UI Vibe">
                    <div className="flex flex-wrap gap-4">
                        {result.colorPalette.map(color => (
                            <div key={color.hex} className="flex-1 min-w-[120px] bg-gray-900/50 border border-gray-800 p-4 rounded-lg">
                                <div style={{ backgroundColor: color.hex }} className="w-full h-16 rounded-md mb-2 border border-white/10"></div>
                                <div className="font-semibold text-white">{color.name}</div>
                                <div className="text-sm text-gray-400 font-mono">{color.hex}</div>
                                <div className="text-sm text-gray-300 mt-1 italic">"{color.vibe}"</div>
                            </div>
                        ))}
                    </div>
                </Section>
            </div>
        </div>
      )}
    </div>
  );
};

const Section: React.FC<{ title: string; items?: string[]; children?: React.ReactNode }> = ({ title, items, children }) => (
  <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
    <h3 className="text-xl font-semibold text-indigo-400 mb-4">{title}</h3>
    {items && <ul className="list-disc list-inside space-y-2 text-gray-300">{items.map((item, i) => <li key={i}>{item}</li>)}</ul>}
    {children}
  </div>
);

export default BrandingStudio;
