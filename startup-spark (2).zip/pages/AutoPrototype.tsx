
import React, { useState, useCallback } from 'react';
import { PageProps, Prototype } from '../types';
import { generatePrototype } from '../services/geminiService';
import { Spinner, BackIcon } from '../components/icons';

const AutoPrototype: React.FC<PageProps> = ({ navigate, idea, setIdea }) => {
  const [result, setResult] = useState<Prototype | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!idea.trim()) {
      setError('Please enter a startup idea.');
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const prototype = await generatePrototype(idea);
      setResult(prototype);
    } catch (e) {
      setError('Failed to generate prototype. Please try again.');
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [idea]);

  return (
    <div className="max-w-5xl mx-auto animate-fade-in">
      <button onClick={() => navigate('home')} className="flex items-center text-indigo-400 hover:text-indigo-300 mb-6 font-semibold">
        <BackIcon />
        Back to Tools
      </button>

      <h2 className="text-3xl font-bold mb-2">Auto-Prototype (Wireframe Mode)</h2>
      <p className="text-gray-400 mb-6">Visualize your product instantly. The AI describes UI layouts and exports Figma instructions and a low-fidelity ASCII wireframe.</p>

      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 mb-8">
        <textarea
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          placeholder="e.g., A landing page for a new AI-powered code editor"
          className="w-full h-24 p-3 bg-gray-800 border border-gray-700 rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-colors"
          disabled={loading}
        />
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="mt-4 w-full flex justify-center items-center px-6 py-3 bg-indigo-600 text-white font-bold rounded-md hover:bg-indigo-700 disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors"
        >
          {loading ? <><Spinner className="mr-2" /> Prototyping...</> : 'Generate Prototype'}
        </button>
        {error && <p className="text-red-400 mt-4 text-center">{error}</p>}
      </div>

      {result && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-fade-in">
          <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-indigo-400 mb-4">Figma Instructions</h3>
            <div className="text-gray-300 whitespace-pre-wrap prose prose-invert prose-sm" dangerouslySetInnerHTML={{ __html: result.figmaInstructions.replace(/\n/g, '<br/>') }} />
          </div>
          <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
            <h3 className="text-xl font-semibold text-indigo-400 mb-4">ASCII Wireframe</h3>
            <pre className="text-gray-400 bg-black p-4 rounded-md overflow-x-auto text-xs leading-relaxed">{result.asciiWireframe}</pre>
          </div>
        </div>
      )}
    </div>
  );
};

export default AutoPrototype;
