
import React, { useState, useCallback } from 'react';
import { PageProps, HistoricalInsightsData } from '../types';
import { generateHistoricalInsights } from '../services/geminiService';
import { Spinner, BackIcon } from '../components/icons';

const HistoricalInsights: React.FC<PageProps> = ({ navigate, idea, setIdea }) => {
  const [result, setResult] = useState<HistoricalInsightsData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    if (!idea.trim()) {
      setError('Please enter a startup idea.');
      return;
    }
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const insights = await generateHistoricalInsights(idea);
      setResult(insights);
    } catch (e) {
      setError('Failed to generate historical insights. Please try again.');
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [idea]);

  const getOutcomeClass = (outcome: string) => {
    if (outcome.toLowerCase().includes('success')) {
      return 'border-green-500/50';
    }
    if (outcome.toLowerCase().includes('fail')) {
      return 'border-red-500/50';
    }
    return 'border-gray-700';
  };
  
  const getOutcomeTextClass = (outcome: string) => {
    if (outcome.toLowerCase().includes('success')) {
      return 'text-green-400';
    }
    if (outcome.toLowerCase().includes('fail')) {
      return 'text-red-400';
    }
    return 'text-gray-400';
  };

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
       <button onClick={() => navigate('home')} className="flex items-center text-indigo-400 hover:text-indigo-300 mb-6 font-semibold">
        <BackIcon />
        Back to Tools
      </button>

      <h2 className="text-3xl font-bold mb-2">Historical Insights Engine</h2>
      <p className="text-gray-400 mb-6">Learn from the successes and failures of the past. The AI analyzes historical data to give your startup a strategic advantage.</p>

      <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 mb-8">
        <textarea
          value={idea}
          onChange={(e) => setIdea(e.target.value)}
          placeholder="e.g., A peer-to-peer marketplace for renting out camera equipment"
          className="w-full h-24 p-3 bg-gray-800 border border-gray-700 rounded-md focus:ring-2 focus:ring-indigo-500 focus:outline-none transition-colors"
          disabled={loading}
        />
        <button
          onClick={handleGenerate}
          disabled={loading}
          className="mt-4 w-full flex justify-center items-center px-6 py-3 bg-indigo-600 text-white font-bold rounded-md hover:bg-indigo-700 disabled:bg-indigo-800 disabled:cursor-not-allowed transition-colors"
        >
          {loading ? <><Spinner className="mr-2" /> Analyzing History...</> : 'Generate Insights'}
        </button>
        {error && <p className="text-red-400 mt-4 text-center">{error}</p>}
      </div>

      {result && (
        <div className="space-y-8 animate-fade-in">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <Section title="✅ Key Success Factors" items={result.keySuccessFactors} itemClassName="text-green-300" />
            <Section title="❌ Common Pitfalls" items={result.commonPitfalls} itemClassName="text-red-300" />
          </div>

          <Section title="Historical Case Studies">
            <div className="space-y-4">
              {result.caseStudies.map((study, i) => (
                <div key={i} className={`p-4 bg-gray-900/50 border border-l-4 rounded-r-lg ${getOutcomeClass(study.outcome)}`}>
                  <h4 className="font-bold text-white">{study.companyName}</h4>
                  <p className={`text-sm font-semibold mb-2 ${getOutcomeTextClass(study.outcome)}`}>{study.outcome}</p>
                  <p className="text-gray-300 italic">"{study.keyLesson}"</p>
                </div>
              ))}
            </div>
          </Section>

          <Section title="Strategic Recommendations" content={result.strategicRecommendations} />
        </div>
      )}
    </div>
  );
};

const Section: React.FC<{ title: string; content?: string; items?: string[]; itemClassName?: string; children?: React.ReactNode }> = ({ title, content, items, itemClassName, children }) => (
    <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6">
        <h3 className="text-xl font-semibold text-indigo-400 mb-4">{title}</h3>
        {content && <p className="text-gray-300 whitespace-pre-wrap">{content}</p>}
        {items && <ul className="list-disc list-inside space-y-2 text-gray-300">{items.map((item, i) => <li key={i} className={itemClassName}>{item}</li>)}</ul>}
        {children}
    </div>
);

export default HistoricalInsights;
