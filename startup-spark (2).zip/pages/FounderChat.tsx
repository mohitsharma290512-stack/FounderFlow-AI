
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { PageProps } from '../types';
import { startFounderChat } from '../services/geminiService';
import { decode, encode, decodeAudioData } from '../utils/audioUtils';
import { LiveServerMessage, Blob, LiveSession } from '@google/genai';
import { BackIcon } from '../components/icons';

type ChatStatus = 'idle' | 'connecting' | 'listening' | 'speaking' | 'error';

const FounderChat: React.FC<Pick<PageProps, 'navigate'>> = ({ navigate }) => {
  const [status, setStatus] = useState<ChatStatus>('idle');
  const [transcripts, setTranscripts] = useState<{ user: string, model: string }[]>([]);
  const [currentInterim, setCurrentInterim] = useState<{ user: string, model: string }>({ user: '', model: '' });

  const sessionPromiseRef = useRef<Promise<LiveSession> | null>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const scriptProcessorRef = useRef<ScriptProcessorNode | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const cleanup = useCallback(() => {
    console.log("Cleaning up resources...");
    
    // Stop microphone stream
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach(track => track.stop());
      mediaStreamRef.current = null;
    }
    
    // Disconnect script processor
    if (scriptProcessorRef.current) {
      scriptProcessorRef.current.disconnect();
      scriptProcessorRef.current = null;
    }

    // Close audio contexts
    if (inputAudioContextRef.current && inputAudioContextRef.current.state !== 'closed') {
      inputAudioContextRef.current.close();
    }
    if (outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
      outputAudioContextRef.current.close();
    }
    
    // Close session
    if (sessionPromiseRef.current) {
        sessionPromiseRef.current.then(session => session.close());
        sessionPromiseRef.current = null;
    }

    setStatus('idle');
  }, []);

  const startSession = async () => {
    if (status !== 'idle') return;

    try {
      setStatus('connecting');
      setTranscripts([]);
      setCurrentInterim({ user: '', model: '' });

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaStreamRef.current = stream;

      inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      let currentInputTranscription = '';
      let currentOutputTranscription = '';

      const callbacks = {
        onopen: () => {
          setStatus('listening');
          const source = inputAudioContextRef.current!.createMediaStreamSource(stream);
          scriptProcessorRef.current = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
          
          scriptProcessorRef.current.onaudioprocess = (audioProcessingEvent) => {
            const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
            const l = inputData.length;
            const int16 = new Int16Array(l);
            for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
            }
            const pcmBlob: Blob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
            };
            if (sessionPromiseRef.current) {
              sessionPromiseRef.current.then((session) => {
                  session.sendRealtimeInput({ media: pcmBlob });
              });
            }
          };
          source.connect(scriptProcessorRef.current);
          scriptProcessorRef.current.connect(inputAudioContextRef.current!.destination);
        },
        onmessage: async (message: LiveServerMessage) => {
          if (message.serverContent?.outputTranscription) {
            currentOutputTranscription += message.serverContent.outputTranscription.text;
            setCurrentInterim(prev => ({ ...prev, model: currentOutputTranscription }));
            setStatus('speaking');
          } else if (message.serverContent?.inputTranscription) {
            currentInputTranscription += message.serverContent.inputTranscription.text;
            setCurrentInterim(prev => ({ ...prev, user: currentInputTranscription }));
          }

          if (message.serverContent?.turnComplete) {
              if (currentInputTranscription || currentOutputTranscription) {
                setTranscripts(prev => [...prev, {user: currentInputTranscription, model: currentOutputTranscription}]);
              }
            currentInputTranscription = '';
            currentOutputTranscription = '';
            setCurrentInterim({ user: '', model: '' });
          }

          const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
          if (base64Audio && outputAudioContextRef.current) {
            const ctx = outputAudioContextRef.current;
            nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
            const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
            const source = ctx.createBufferSource();
            source.buffer = audioBuffer;
            source.connect(ctx.destination);
            source.addEventListener('ended', () => {
              sourcesRef.current.delete(source);
              if (sourcesRef.current.size === 0) {
                  setStatus('listening');
              }
            });
            source.start(nextStartTimeRef.current);
            nextStartTimeRef.current += audioBuffer.duration;
            sourcesRef.current.add(source);
          }
        },
        onerror: (e: ErrorEvent) => {
          console.error('Session error:', e);
          setStatus('error');
          cleanup();
        },
        onclose: () => {
          console.log('Session closed');
          cleanup();
        },
      };

      sessionPromiseRef.current = startFounderChat(callbacks);

    } catch (err) {
      console.error('Failed to start session:', err);
      setStatus('error');
    }
  };

  useEffect(() => {
      return () => cleanup();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="max-w-4xl mx-auto animate-fade-in">
        <button onClick={() => navigate('home')} className="flex items-center text-indigo-400 hover:text-indigo-300 mb-6 font-semibold">
            <BackIcon />
            Back to Tools
        </button>

        <h2 className="text-3xl font-bold mb-2">Founder Chat</h2>
        <p className="text-gray-400 mb-6">Talk with your AI advisor. Get a motivational boost, gut-check decisions, and gain clarity on your founder journey.</p>
        
        <div className="bg-gray-900/50 border border-gray-800 rounded-lg p-6 min-h-[400px] flex flex-col">
            <div className="flex-grow space-y-4 mb-4 pr-2 overflow-y-auto">
                {transcripts.map((t, i) => (
                    <div key={i}>
                        {t.user && <div className="text-right"><span className="bg-indigo-600 px-3 py-2 rounded-lg inline-block">{t.user}</span></div>}
                        {t.model && <div className="text-left mt-2"><span className="bg-gray-700 px-3 py-2 rounded-lg inline-block">{t.model}</span></div>}
                    </div>
                ))}
                 {currentInterim.user && <div className="text-right"><span className="bg-indigo-600/50 px-3 py-2 rounded-lg inline-block">{currentInterim.user}</span></div>}
                 {currentInterim.model && <div className="text-left mt-2"><span className="bg-gray-700/50 px-3 py-2 rounded-lg inline-block">{currentInterim.model}</span></div>}
            </div>
            
            <div className="flex-shrink-0 text-center pt-4 border-t border-gray-800">
                {status === 'idle' && (
                    <button onClick={startSession} className="px-6 py-3 bg-green-600 text-white font-bold rounded-full hover:bg-green-700 transition-colors">Start Chat</button>
                )}
                 {status === 'connecting' && <p className="text-yellow-400">Connecting...</p>}
                 {status === 'listening' && <p className="text-green-400">Listening...</p>}
                 {status === 'speaking' && <p className="text-blue-400">AI is speaking...</p>}
                 {status === 'error' && <p className="text-red-400">An error occurred. Please refresh.</p>}

                {(status === 'listening' || status === 'speaking') && (
                    <button onClick={cleanup} className="mt-2 px-6 py-3 bg-red-600 text-white font-bold rounded-full hover:bg-red-700 transition-colors">End Chat</button>
                )}
            </div>
        </div>
    </div>
  );
};

export default FounderChat;
