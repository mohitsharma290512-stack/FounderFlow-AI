
import React from 'react';
import { Page } from '../types';
import {
  BlueprintIcon, PitchDeckIcon, TaskPlannerIcon, BrandingStudioIcon,
  MarketResearchIcon, AutoPrototypeIcon, FounderChatIcon, HistoricalInsightsIcon
} from '../components/icons';

interface Feature {
  id: Page;
  title: string;
  description: string;
  Icon: React.FC;
}

const features: Feature[] = [
  { id: 'blueprint', title: 'Blueprint Generator', description: 'Convert any idea into a detailed business plan.', Icon: BlueprintIcon },
  { id: 'pitch_deck', title: 'Pitch Deck Maker', description: 'Generate investor decks, demo scripts & elevator pitches.', Icon: PitchDeckIcon },
  { id: 'task_planner', title: 'Founder To-Do Planner', description: 'Break down goals into actionable tasks and milestones.', Icon: TaskPlannerIcon },
  { id: 'branding', title: 'Branding Studio', description: 'Instantly create names, taglines, and brand identity.', Icon: BrandingStudioIcon },
  { id: 'market_research', title: 'Competitor Research', description: 'Analyze competitors and discover your market edge.', Icon: MarketResearchIcon },
  { id: 'prototype', title: 'Auto-Prototype', description: 'Generate UI layouts and low-fidelity wireframes.', Icon: AutoPrototypeIcon },
  { id: 'founder_chat', title: 'Founder Chat', description: 'Talk with an AI advisor for coaching and clarity.', Icon: FounderChatIcon },
  { id: 'historical_insights', title: 'Historical Insights', description: 'Learn from 20 years of startup history to avoid pitfalls.', Icon: HistoricalInsightsIcon },
];

interface HomeProps {
  navigate: (page: Page) => void;
}

const Home: React.FC<HomeProps> = ({ navigate }) => {
  return (
    <div className="animate-fade-in">
      <div className="text-center mb-12">
        <h2 className="text-4xl md:text-5xl font-extrabold text-white mb-4">Turn Your Vision into a Venture</h2>
        <p className="text-lg md:text-xl text-gray-400 max-w-3xl mx-auto">Select a tool to begin building your startup. Your AI co-pilot is ready to help you innovate, strategize, and execute.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {features.map((feature) => (
          <div
            key={feature.id}
            onClick={() => navigate(feature.id)}
            className="group bg-gray-900/50 border border-gray-800 rounded-xl p-6 cursor-pointer hover:bg-gray-800/60 hover:border-indigo-500/50 transition-all duration-300 transform hover:-translate-y-1"
          >
            <feature.Icon />
            <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
            <p className="text-gray-400 group-hover:text-gray-300 transition-colors">{feature.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Home;
