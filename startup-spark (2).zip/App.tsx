
import React, { useState, useCallback } from 'react';
import Home from './pages/Home';
import BlueprintGenerator from './pages/BlueprintGenerator';
import PitchDeckMaker from './pages/PitchDeckMaker';
import TaskPlanner from './pages/TaskPlanner';
import BrandingStudio from './pages/BrandingStudio';
import MarketResearch from './pages/MarketResearch';
import AutoPrototype from './pages/AutoPrototype';
import FounderChat from './pages/FounderChat';
import HistoricalInsights from './pages/HistoricalInsights';
import Header from './components/Header';
import { Page } from './types';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [idea, setIdea] = useState<string>('');

  const navigate = useCallback((page: Page) => {
    setCurrentPage(page);
  }, []);

  const renderPage = () => {
    const pageProps = { navigate, idea, setIdea };
    switch (currentPage) {
      case 'blueprint':
        return <BlueprintGenerator {...pageProps} />;
      case 'pitch_deck':
        return <PitchDeckMaker {...pageProps} />;
      case 'task_planner':
        return <TaskPlanner {...pageProps} />;
      case 'branding':
        return <BrandingStudio {...pageProps} />;
      case 'market_research':
        return <MarketResearch {...pageProps} />;
      case 'prototype':
        return <AutoPrototype {...pageProps} />;
      case 'founder_chat':
        return <FounderChat {...pageProps} />;
      case 'historical_insights':
        return <HistoricalInsights {...pageProps} />;
      case 'home':
      default:
        return <Home navigate={navigate} />;
    }
  };

  return (
    <div className="min-h-screen bg-black text-gray-100 font-sans">
      <Header />
      <main className="container mx-auto px-4 py-8">
        {renderPage()}
      </main>
    </div>
  );
};

export default App;
