
import { GoogleGenAI, Type, Modality, LiveSession } from "@google/genai";
import { Blueprint, PitchDeck, Task, Branding, MarketResearchData, Prototype, HistoricalInsightsData } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateBlueprint = async (idea: string): Promise<Blueprint> => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-pro',
    contents: `Based on the startup idea "${idea}", generate a detailed startup blueprint.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          problemStatement: { type: Type.STRING, description: "A concise statement of the problem this startup solves." },
          targetUsers: { type: Type.ARRAY, items: { type: Type.STRING }, description: "A list of specific target user personas." },
          marketFit: { type: Type.STRING, description: "An analysis of how the product fits into the current market." },
          monetizationStrategy: { type: Type.STRING, description: "Primary and secondary strategies for generating revenue." },
          launchRoadmap: { type: Type.ARRAY, items: {
            type: Type.OBJECT,
            properties: {
              phase: { type: Type.STRING },
              details: { type: Type.STRING }
            }
          }, description: "A phased roadmap for launching the startup."}
        },
        required: ["problemStatement", "targetUsers", "marketFit", "monetizationStrategy", "launchRoadmap"]
      },
    }
  });
  return JSON.parse(response.text.trim());
};

export const generatePitchDeck = async (idea: string): Promise<PitchDeck> => {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: `For a startup with the idea "${idea}", create a 10-slide investor deck outline, a demo video script, and elevator pitches for 30 seconds, 60 seconds, and 3 minutes.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            deckOutline: {
              type: Type.ARRAY,
              description: "A 10-slide deck outline.",
              items: {
                type: Type.OBJECT,
                properties: {
                  slide: { type: Type.INTEGER },
                  title: { type: Type.STRING },
                  content: { type: Type.STRING, description: "Key points for the slide." }
                }
              }
            },
            demoScript: { type: Type.STRING, description: "A script for a demo video, including narration." },
            elevatorPitches: {
              type: Type.OBJECT,
              properties: {
                thirtySecond: { type: Type.STRING },
                sixtySecond: { type: Type.STRING },
                threeMinute: { type: Type.STRING }
              }
            }
          },
          required: ["deckOutline", "demoScript", "elevatorPitches"]
        },
      }
    });
    return JSON.parse(response.text.trim());
  };
  
export const generateTaskPlanner = async (idea: string): Promise<{ tasks: Task[] }> => {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: `Break down the initial goals for a startup with the idea "${idea}" into a list of actionable tasks for the first three months. Include milestones, priority labels, and suggested deadlines.`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    tasks: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                task: { type: Type.STRING },
                                milestone: { type: Type.STRING, description: "e.g., 'Week 1: Foundation', 'Month 1: MVP Scoping'" },
                                priority: { type: Type.STRING, enum: ["High", "Medium", "Low"] },
                                deadline: { type: Type.STRING, description: "e.g., 'End of Week 1'" }
                            },
                            required: ["task", "milestone", "priority", "deadline"]
                        }
                    }
                },
                required: ["tasks"]
            }
        }
    });
    return JSON.parse(response.text.trim());
};
  
export const generateBranding = async (idea: string): Promise<Branding> => {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: `Generate branding assets for a startup idea: "${idea}". I need a list of potential names, taglines, a descriptive prompt for a logo design, and a color palette with hex codes and the vibe each color represents.`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    names: { type: Type.ARRAY, items: { type: Type.STRING } },
                    taglines: { type: Type.ARRAY, items: { type: Type.STRING } },
                    logoPrompt: { type: Type.STRING, description: "A detailed prompt for an AI image generator to create a logo." },
                    colorPalette: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                hex: { type: Type.STRING },
                                name: { type: Type.STRING },
                                vibe: { type: Type.STRING }
                            },
                             required: ["hex", "name", "vibe"]
                        }
                    }
                },
                required: ["names", "taglines", "logoPrompt", "colorPalette"]
            }
        }
    });
    return JSON.parse(response.text.trim());
};
  
export const generateMarketResearch = async (idea: string): Promise<MarketResearchData> => {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: `Conduct market research for a startup idea: "${idea}". Identify top 3 potential competitors, their pricing models, their key strengths and weaknesses, and suggest a strategy for how the new startup can differentiate and win. Provide a summary of the market.`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    marketSummary: { type: Type.STRING, description: "A brief overview of the market landscape." },
                    competitors: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                name: { type: Type.STRING },
                                pricing: { type: Type.STRING },
                                strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
                                weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
                                strategyToBeat: { type: Type.STRING }
                            },
                            required: ["name", "pricing", "strengths", "weaknesses", "strategyToBeat"]
                        }
                    }
                },
                required: ["marketSummary", "competitors"]
            }
        }
    });
    return JSON.parse(response.text.trim());
};
  
export const generatePrototype = async (idea: string): Promise<Prototype> => {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: `For a startup idea "${idea}", describe a UI layout for the main landing page. Provide this in two formats: 1. A set of clear, actionable instructions for a designer using Figma. 2. A low-fidelity ASCII art wireframe of the layout.`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    figmaInstructions: { type: Type.STRING, description: "Numbered steps for a designer in Figma." },
                    asciiWireframe: { type: Type.STRING, description: "A text-based representation of the UI layout." }
                },
                required: ["figmaInstructions", "asciiWireframe"]
            }
        }
    });
    return JSON.parse(response.text.trim());
};

export const generateHistoricalInsights = async (idea: string): Promise<HistoricalInsightsData> => {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-pro',
        contents: `Based on the startup idea "${idea}", act as a startup historian and analyst. Analyze successful and failed startups from the past 20 years in a similar space. Identify key success factors, common pitfalls to avoid, and provide 3-5 brief case studies (both success and failure). Conclude with strategic recommendations for the new founder to help them avoid repeating past failures and build a smarter company.`,
        config: {
            responseMimeType: "application/json",
            responseSchema: {
                type: Type.OBJECT,
                properties: {
                    keySuccessFactors: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                        description: "Factors that led to success in similar ventures."
                    },
                    commonPitfalls: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                        description: "Common mistakes that led to failure in similar ventures."
                    },
                    caseStudies: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                companyName: { type: Type.STRING },
                                outcome: { type: Type.STRING, description: "e.g., 'Success (Acquired)', 'Failure (Shut down)'" },
                                keyLesson: { type: Type.STRING }
                            },
                            required: ["companyName", "outcome", "keyLesson"]
                        }
                    },
                    strategicRecommendations: {
                        type: Type.STRING,
                        description: "Overall strategic recommendations for the founder."
                    }
                },
                required: ["keySuccessFactors", "commonPitfalls", "caseStudies", "strategicRecommendations"]
            }
        }
    });
    return JSON.parse(response.text.trim());
};

export const startFounderChat = async (callbacks: any): Promise<LiveSession> => {
    return ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks,
        config: {
          responseModalities: [Modality.AUDIO],
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
          },
          systemInstruction: `You are Spark, an expert startup advisor and motivational coach. 
          Your tone is encouraging, insightful, and human-like. You help founders clarify their thinking, 
          make tough business decisions, and stay motivated. Keep your responses concise and conversational.`,
        },
    });
};
